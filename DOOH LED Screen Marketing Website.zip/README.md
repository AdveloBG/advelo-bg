
  # DOOH LED Screen Marketing Website

  This is a code bundle for DOOH LED Screen Marketing Website. The original project is available at https://www.figma.com/design/1OSNSdaW6DpbW26we6u2Jd/DOOH-LED-Screen-Marketing-Website.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  