import { Suspense, lazy } from "react";
import { ErrorBoundary } from "./components/ErrorBoundary";
import { Header } from "./components/Header";
import { ThemeProvider } from "./components/ThemeProvider";
import { Toaster } from "./components/ui/sonner";
import { PageLoader } from "./components/LoadingSpinner";

// Lazy load components for better performance
const HeroSection = lazy(() => import("./components/HeroSection").then(module => ({ default: module.HeroSection })));
const StatisticsSection = lazy(() => import("./components/StatisticsSection").then(module => ({ default: module.StatisticsSection })));
const PricingSection = lazy(() => import("./components/PricingSection").then(module => ({ default: module.PricingSection })));
const ShowcaseSection = lazy(() => import("./components/ShowcaseSection").then(module => ({ default: module.ShowcaseSection })));
const FeaturesSection = lazy(() => import("./components/FeaturesSection").then(module => ({ default: module.FeaturesSection })));
const ContactSection = lazy(() => import("./components/ContactSection").then(module => ({ default: module.ContactSection })));
const Footer = lazy(() => import("./components/Footer").then(module => ({ default: module.Footer })));

export default function App() {
  return (
    <ErrorBoundary>
      <ThemeProvider>
        <div className="min-h-screen bg-background text-foreground transition-colors duration-300">
          {/* Header is loaded immediately as it's above the fold */}
          <Header />
          
          <main id="main-content" className="relative">
            <Suspense fallback={<PageLoader />}>
              {/* Hero section loads immediately as it's critical above-the-fold content */}
              <HeroSection />
              
              {/* Other sections can be lazy loaded */}
              <Suspense fallback={<div className="h-96 flex items-center justify-center"><div className="animate-pulse text-muted-foreground">Зарежда статистики...</div></div>}>
                <StatisticsSection />
              </Suspense>
              
              <Suspense fallback={<div className="h-96 flex items-center justify-center"><div className="animate-pulse text-muted-foreground">Зарежда цени...</div></div>}>
                <PricingSection />
              </Suspense>
              
              <Suspense fallback={<div className="h-96 flex items-center justify-center"><div className="animate-pulse text-muted-foreground">Зарежда галерия...</div></div>}>
                <ShowcaseSection />
              </Suspense>
              
              <Suspense fallback={<div className="h-96 flex items-center justify-center"><div className="animate-pulse text-muted-foreground">Зарежда функции...</div></div>}>
                <FeaturesSection />
              </Suspense>
              
              <Suspense fallback={<div className="h-96 flex items-center justify-center"><div className="animate-pulse text-muted-foreground">Зарежда контакти...</div></div>}>
                <ContactSection />
              </Suspense>
            </Suspense>
          </main>
          
          <Suspense fallback={<div className="h-32 bg-secondary/20 animate-pulse"></div>}>
            <Footer />
          </Suspense>
          
          {/* Toast notifications */}
          <Toaster 
            position="top-right"
            className="bg-card border-border"
            closeButton
            richColors
            toastOptions={{
              className: "bg-card border-border text-card-foreground",
              duration: 5000,
            }}
          />
        </div>
      </ThemeProvider>
    </ErrorBoundary>
  );
}