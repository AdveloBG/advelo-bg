# 🚀 Complete Deployment Guide for Advelo Website

## Quick Start - Choose Your Platform

Your website is **100% ready to deploy** with any of these platforms:

### 🎯 **RECOMMENDED: Netlify (Easiest & Free)**
### ⚡ **Alternative: Vercel (Fast & Free)**  
### 🏢 **Traditional: Any Web Host**

---

## 🎯 **Option 1: Netlify Deployment (RECOMMENDED)**

### **Why Netlify?**
- ✅ **FREE hosting** for personal/business sites
- ✅ **Automatic HTTPS** certificate
- ✅ **Global CDN** for fast loading worldwide
- ✅ **Automatic deployments** from GitHub
- ✅ **Perfect for Bulgarian businesses**

### **Step-by-Step Netlify Deployment:**

#### **Method A: Deploy from GitHub (Recommended)**

1. **Upload your code to GitHub:**
   ```bash
   # In your project folder, run:
   git init
   git add .
   git commit -m "Initial commit - Advelo website ready for production"
   
   # Create a new repository on GitHub, then:
   git remote add origin https://github.com/YOUR_USERNAME/advelo-website.git
   git push -u origin main
   ```

2. **Deploy on Netlify:**
   - Go to [netlify.com](https://netlify.com)
   - Click **"Sign up"** (free account)
   - Click **"New site from Git"**
   - Choose **GitHub** and authorize Netlify
   - Select your **advelo-website** repository
   - **Build settings** (Netlify will auto-detect):
     - **Build command:** `npm run build`
     - **Publish directory:** `dist`
   - Click **"Deploy site"**

3. **Your website will be live in 2-3 minutes!**
   - Netlify gives you a URL like: `https://amazing-name-123456.netlify.app`
   - You can change this to: `https://advelo.netlify.app` (if available)

#### **Method B: Direct File Upload**

1. **Build your website locally:**
   ```bash
   npm install
   npm run build
   ```

2. **Upload to Netlify:**
   - Go to [netlify.com](https://netlify.com) → Sign up (free)
   - Drag and drop the **`dist`** folder to Netlify
   - Your site is instantly live!

---

## ⚡ **Option 2: Vercel Deployment**

### **Step-by-Step Vercel Deployment:**

1. **Upload to GitHub** (same as Netlify step 1)

2. **Deploy on Vercel:**
   - Go to [vercel.com](https://vercel.com)
   - Click **"Sign up"** (free with GitHub)
   - Click **"New Project"**
   - Import your **advelo-website** repository
   - Vercel auto-detects everything
   - Click **"Deploy"**

3. **Live in under 1 minute!**
   - Gets URL like: `https://advelo-website.vercel.app`

---

## 🏢 **Option 3: Traditional Web Hosting**

### **For any web hosting provider (Hostgator, Bluehost, etc.):**

1. **Build the website:**
   ```bash
   npm install
   npm run build
   ```

2. **Upload files:**
   - Upload **ALL contents** of the `dist` folder to your hosting's `public_html` folder
   - Make sure your hosting supports **Single Page Applications (SPA)**

3. **Configure your server:**
   - Add this to your `.htaccess` file (for Apache servers):
   ```apache
   RewriteEngine On
   RewriteBase /
   RewriteRule ^index\.html$ - [L]
   RewriteCond %{REQUEST_FILENAME} !-f
   RewriteCond %{REQUEST_FILENAME} !-d
   RewriteRule . /index.html [L]
   ```

---

## 🌐 **Custom Domain Setup**

### **After deployment, add your own domain:**

#### **For Netlify:**
1. Go to **Site settings** → **Domain management**
2. Click **"Add custom domain"**
3. Enter your domain (e.g., `advelo.bg`)
4. Update your domain's DNS settings:
   ```
   Type: CNAME
   Name: www
   Value: your-site-name.netlify.app
   
   Type: A
   Name: @
   Value: 75.2.60.5
   ```

#### **For Vercel:**
1. Go to **Project Settings** → **Domains**
2. Add your domain
3. Update DNS settings as instructed

---

## ⚙️ **Final Configuration Steps**

### **1. Update Your Domain References:**
Once you have your live URL, update these files:

```bash
# In index.html - Replace https://advelo.bg with your actual domain
# In sitemap.xml - Replace https://advelo.bg with your actual domain
# In public/site.webmanifest - Update start_url if needed
```

### **2. Environment Variables (Optional):**
Create these environment variables in your hosting platform:

```bash
VITE_APP_URL=https://yourdomain.com
VITE_CONTACT_EMAIL=contact@advelo.bg
VITE_CONTACT_PHONE=+359889792777
```

### **3. Google Analytics (Optional):**
- Uncomment the Google Analytics code in `index.html`
- Add your GA tracking ID
- Track your website performance

---

## 📊 **Post-Deployment Checklist**

### **Test Your Live Website:**
- ✅ Check all sections load correctly
- ✅ Test the contact form
- ✅ Verify theme toggle works
- ✅ Test on mobile devices
- ✅ Check loading speed

### **SEO Setup:**
- ✅ Submit your sitemap to [Google Search Console](https://search.google.com/search-console)
- ✅ Submit to [Bing Webmaster Tools](https://www.bing.com/webmasters)
- ✅ Test social media previews

### **Performance Monitoring:**
- ✅ Run [Google PageSpeed Insights](https://pagespeed.web.dev)
- ✅ Test with [GTmetrix](https://gtmetrix.com)
- ✅ Check [Lighthouse](https://developers.google.com/web/tools/lighthouse) scores

---

## 🎯 **QUICK START RECOMMENDATION**

### **For Fastest Deployment (5 minutes):**

1. **Go to [netlify.com](https://netlify.com)**
2. **Sign up** with GitHub (free)
3. **Build your site locally:**
   ```bash
   npm install
   npm run build
   ```
4. **Drag the `dist` folder** to Netlify
5. **Your website is LIVE!** 🎉

### **For Automatic Updates:**
- Upload to GitHub first
- Connect GitHub to Netlify
- Every code change auto-deploys

---

## 💡 **Pro Tips for Bulgarian Market**

### **Domain Suggestions:**
- `advelo.bg` (if available)
- `advelo.eu`
- `advelo-mobile.com`
- `mobileadvelo.bg`

### **Hosting in Bulgaria:**
- [SuperHosting.bg](https://superhosting.bg)
- [ICN.bg](https://icn.bg)
- [Host.bg](https://host.bg)

### **Local SEO:**
- Submit to Bulgarian business directories
- Add Google My Business listing
- Optimize for Bulgarian search terms

---

## 🚨 **Troubleshooting**

### **Common Issues:**

#### **"Page not found" on refresh:**
- Add the `.htaccess` rewrite rules (for Apache)
- Enable SPA support in your hosting

#### **Images not loading:**
- Check if all images in the `dist/assets` folder uploaded
- Verify image paths are correct

#### **Contact form not working:**
- Remember to set up a backend for form processing
- Consider using Netlify Forms (built-in) or Formspree

---

## 🎉 **You're Ready to Launch!**

Your Advelo website is **production-ready** and can be deployed to any of these platforms in under 10 minutes!

**Recommended path:**
1. **Netlify** (free, fast, easy)
2. **Add custom domain** 
3. **Submit to search engines**
4. **Start driving traffic!**

**Need help?** Your website includes:
- ✅ Complete SEO optimization
- ✅ Mobile responsiveness  
- ✅ Professional design
- ✅ Contact form validation
- ✅ Analytics ready
- ✅ Social media integration

---

**🚀 Deploy now and start growing your mobile advertising business in Bulgaria!**