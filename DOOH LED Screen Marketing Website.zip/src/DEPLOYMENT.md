# 🚀 Advelo Website Deployment Guide

Comprehensive guide for deploying the Advelo website from development to production.

## 📋 Prerequisites

### Local Development Requirements
- **Node.js** 18.0.0+ 
- **npm** 8.0.0+ or **yarn** 1.22.0+
- **Git** for version control

### Required Accounts
- **Netlify** or **Vercel** account for hosting
- **GitHub** account for code repository
- **Google Analytics** account (optional)
- **Domain registrar** account for custom domain

## 🛠️ Local Setup

### 1. Clone and Install
```bash
# Clone the repository
git clone https://github.com/yourusername/advelo-website.git
cd advelo-website

# Install dependencies
npm install

# Copy environment variables
cp .env.example .env
```

### 2. Environment Configuration
Edit `.env` file with your values:
```bash
# API Configuration
VITE_API_URL=https://api.advelo.bg
VITE_CONTACT_FORM_ENDPOINT=/contact

# Analytics (optional)
VITE_GA_MEASUREMENT_ID=G-XXXXXXXXXX

# Contact Information
VITE_CONTACT_EMAIL=info@advelo.bg
VITE_CONTACT_PHONE=+359123456789

# Feature Flags
VITE_ENABLE_ANALYTICS=true
VITE_MAINTENANCE_MODE=false
```

### 3. Development Server
```bash
# Start development server
npm run dev

# Open http://localhost:3000
```

### 4. Build and Test
```bash
# Type check
npm run type-check

# Lint code
npm run lint

# Build for production
npm run build

# Preview production build
npm run preview
```

## 🌐 Production Deployment

### Option 1: Netlify (Recommended)

#### Automatic Deployment
1. **Push to GitHub**
   ```bash
   git add .
   git commit -m "Ready for deployment"
   git push origin main
   ```

2. **Connect to Netlify**
   - Go to [Netlify](https://netlify.com)
   - Click "Add new site" → "Import from Git"
   - Connect your GitHub repository
   - Configure build settings:
     - **Build command**: `npm run build`
     - **Publish directory**: `dist`
     - **Node version**: `18`

3. **Environment Variables**
   In Netlify dashboard → Site settings → Environment variables:
   ```
   VITE_API_URL=https://api.advelo.bg
   VITE_CONTACT_EMAIL=info@advelo.bg
   VITE_CONTACT_PHONE=+359123456789
   VITE_GA_MEASUREMENT_ID=G-XXXXXXXXXX
   ```

4. **Custom Domain**
   - Go to Domain settings
   - Add your domain (e.g., `advelo.bg`)
   - Configure DNS records with your domain registrar
   - Enable HTTPS (automatic with Netlify)

#### Manual Deployment
```bash
# Install Netlify CLI
npm install -g netlify-cli

# Login to Netlify
netlify login

# Deploy to production
netlify deploy --prod --dir=dist
```

### Option 2: Vercel

1. **Connect Repository**
   - Go to [Vercel](https://vercel.com)
   - Import your GitHub repository
   - Configure:
     - **Framework**: Vite
     - **Build command**: `npm run build`
     - **Output directory**: `dist`

2. **Environment Variables**
   Add in Vercel dashboard:
   ```
   VITE_API_URL=https://api.advelo.bg
   VITE_CONTACT_EMAIL=info@advelo.bg
   VITE_CONTACT_PHONE=+359123456789
   ```

3. **Custom Domain**
   - Go to Project Settings → Domains
   - Add your domain
   - Configure DNS records

### Option 3: Manual Server Deployment

```bash
# Build the project
npm run build

# Upload dist/ folder to your server
scp -r dist/* user@yourserver.com:/var/www/html/

# Configure nginx/apache to serve static files
```

## 🔧 Backend Integration

### Contact Form API
The website expects a backend API endpoint for form submissions:

```typescript
// Expected API endpoint: POST /api/contact
interface ContactRequest {
  name: string;
  email: string;
  phone: string;
  company: string;
  screens: string;
  period: string;
  message: string;
}

interface ContactResponse {
  success: boolean;
  message: string;
}
```

### Example Backend (Node.js/Express)
```javascript
const express = require('express');
const nodemailer = require('nodemailer');
const app = express();

app.post('/api/contact', async (req, res) => {
  try {
    const { name, email, phone, company, screens, period, message } = req.body;
    
    // Send email notification
    const transporter = nodemailer.createTransporter({
      // Configure your email service
    });
    
    await transporter.sendMail({
      from: process.env.SMTP_FROM,
      to: process.env.CONTACT_EMAIL,
      subject: `Нова заявка от ${name} - ${company}`,
      html: `
        <h2>Нова заявка за LED реклама</h2>
        <p><strong>Име:</strong> ${name}</p>
        <p><strong>Фирма:</strong> ${company}</p>
        <p><strong>Email:</strong> ${email}</p>
        <p><strong>Телефон:</strong> ${phone}</p>
        <p><strong>Брой екрани:</strong> ${screens}</p>
        <p><strong>Период:</strong> ${period}</p>
        <p><strong>Съобщение:</strong> ${message}</p>
      `
    });
    
    res.json({ success: true, message: 'Заявката е изпратена успешно!' });
  } catch (error) {
    console.error('Contact form error:', error);
    res.status(500).json({ success: false, message: 'Възникна грешка' });
  }
});
```

## 📊 Analytics & Monitoring

### Google Analytics Setup
1. Create GA4 property
2. Get Measurement ID (G-XXXXXXXXXX)
3. Add to environment variables
4. Analytics will auto-track:
   - Page views
   - Form submissions
   - Performance metrics

### Performance Monitoring
```bash
# Install Lighthouse CLI
npm install -g @lhci/cli

# Run performance audit
lhci autorun

# Check Core Web Vitals
npm run build && npm run preview
# Visit localhost:4173 and check DevTools → Lighthouse
```

## 🔒 Security Setup

### Content Security Policy
Update `netlify.toml` or server config:
```
Content-Security-Policy: default-src 'self'; script-src 'self' 'unsafe-inline' *.googletagmanager.com; style-src 'self' 'unsafe-inline' fonts.googleapis.com; font-src 'self' fonts.gstatic.com; img-src 'self' data: https:;
```

### SSL Certificate
- **Netlify/Vercel**: Automatic HTTPS
- **Custom server**: Use Let's Encrypt or commercial certificate

## 📱 Testing Checklist

### Pre-deployment Testing
- [ ] **Desktop**: Chrome, Firefox, Safari, Edge
- [ ] **Mobile**: iOS Safari, Android Chrome
- [ ] **Tablet**: iPad, Android tablets
- [ ] **Performance**: Lighthouse score > 90
- [ ] **Accessibility**: WCAG 2.1 AA compliance
- [ ] **Forms**: Contact form submission works
- [ ] **Navigation**: All links work correctly
- [ ] **Theme**: Dark/light mode switching
- [ ] **Responsive**: All breakpoints work

### Production Testing
```bash
# Test production build locally
npm run build
npm run preview

# Test on multiple devices
# Use BrowserStack, Sauce Labs, or manual testing
```

## 🚨 Troubleshooting

### Common Issues

**Build Errors**
```bash
# Clear cache and reinstall
rm -rf node_modules package-lock.json
npm install
npm run build
```

**Environment Variables Not Working**
- Ensure variables start with `VITE_`
- Check they're set in deployment platform
- Restart development server after changes

**Form Submissions Not Working**
- Check API endpoint URL
- Verify CORS settings on backend
- Check browser network tab for errors

**Performance Issues**
```bash
# Analyze bundle size
npm run build
npx vite-bundle-analyzer dist/stats.html

# Check for unused dependencies
npx depcheck
```

**Styling Issues**
- Check Tailwind CSS classes are correct
- Verify dark/light theme variables
- Test on different screen sizes

## 📞 Support

### Getting Help
- **Technical Issues**: Check GitHub Issues
- **Deployment Problems**: Contact hosting provider support
- **Custom Development**: Consider hiring a developer

### Useful Resources
- [Vite Documentation](https://vitejs.dev/)
- [React Documentation](https://react.dev/)
- [Tailwind CSS Documentation](https://tailwindcss.com/)
- [Netlify Documentation](https://docs.netlify.com/)
- [Vercel Documentation](https://vercel.com/docs)

## 🔄 Maintenance

### Regular Updates
```bash
# Update dependencies monthly
npm update
npm audit fix

# Check for security issues
npm audit

# Update Node.js annually
```

### Backup Strategy
- **Code**: Stored in Git repository
- **Environment configs**: Document all settings
- **Analytics**: Export important data regularly

### Monitoring
- Set up uptime monitoring (UptimeRobot, Pingdom)
- Monitor Core Web Vitals in Google Search Console
- Check error logs regularly

---

## 🎉 You're Ready to Launch!

Your Advelo website is now ready for production deployment. Follow this guide step by step, and you'll have a professional, fast, and secure website running in no time!

**Need help?** Create an issue in the GitHub repository or contact your development team.

**Good luck with your launch! 🚀**