# Advelo - Мобилна LED Реклама

Професионален уебсайт за Advelo - водеща компания за мобилна LED реклама в България.

## ✨ Функционалности

- **🎨 Адаптивен дизайн** - Перфектна работа на всички устройства
- **🌙 Тъмен/Светъл режим** - Превключване между теми с едно натискане
- **📊 Интерактивни статистики** - Реални данни и аналитика
- **🚀 Модерна анимация** - Плавни CSS3 и JavaScript анимации
- **♿ Достъпност** - WCAG 2.1 съвместимост
- **⚡ Оптимизирана производителност** - Бързо зареждане и SEO оптимизация

## 🛠️ Технологии

- **React 18** - Модерен UI framework
- **TypeScript** - Type-safe развитие
- **Tailwind CSS v4** - Utility-first CSS framework
- **Recharts** - Красиви и интерактивни графики
- **Lucide React** - Модерни SVG икони
- **Vite** - Бърз build tool

## 🚀 Стартиране на проекта

### Предварителни изисквания
- Node.js 18.0.0 или по-нова версия
- npm или yarn

### Инсталация

```bash
# Клониране на репозиторията
git clone [repository-url]
cd advelo-website

# Инсталация на зависимости
npm install

# Стартиране в development режим
npm run dev

# Build за production
npm run build

# Preview на production build
npm run preview
```

## 📁 Структура на проекта

```
src/
├── components/
│   ├── ui/                 # ShadCN UI компоненти
│   ├── data/               # Данни за съдържанието
│   ├── ContactSection.tsx  # Секция за контакти
│   ├── FeaturesSection.tsx # Секция с предимства
│   ├── Footer.tsx          # Долен колонтитул
│   ├── Header.tsx          # Горен колонтитул
│   ├── HeroSection.tsx     # Главна секция
│   ├── PricingSection.tsx  # Секция с цени
│   ├── ShowcaseSection.tsx # Демо секция
│   ├── StatisticsSection.tsx # Статистики
│   ├── ThemeProvider.tsx   # Управление на теми
│   └── ThemeToggle.tsx     # Превключвател на теми
├── styles/
│   └── globals.css         # Глобални стилове
├── App.tsx                 # Главен компонент
└── main.tsx               # Entry point
```

## 🎨 Дизайн система

### Цветове
- **Тъмна тема**: Черен фон (#000000) с лайм зелен акцент (#22c55e)
- **Светла тема**: Бежов фон (#f7f5f0) с зелени и сини акценти

### Типография
- **Font Family**: Outfit (Google Fonts)
- **Responsive sizing**: clamp() функции за всички текстови елементи
- **Font weights**: 300-900

### Компоненти
- **Карти**: Стъклен ефект с blur backdrop
- **Бутони**: Hover ефекти и focus states
- **Анимации**: Плавни transitions и keyframe анимации

## 🔧 Конфигурация

### Tailwind CSS
Използва се Tailwind v4 с custom CSS variables за темите:

```css
:root {
  --primary: #22c55e;
  --background: #000000;
  --foreground: #ffffff;
  /* ... други променливи */
}
```

### Responsive Breakpoints
- **Mobile**: < 640px
- **Tablet**: 640px - 1024px
- **Desktop**: > 1024px

## 📊 Производителност

### Оптимизации
- **Lazy loading** за изображения
- **Code splitting** за компоненти
- **CSS-in-JS** минимизиран
- **Bundle size** оптимизиран
- **Core Web Vitals** съвместимост

### SEO
- **Semantic HTML** за всички секции
- **Meta tags** за social media
- **Schema.org** микроданни
- **Accessible navigation** с skip links

## ♿ Достъпност

### WCAG 2.1 Compliance
- **Keyboard navigation** за всички интерактивни елементи
- **Screen reader** съвместимост
- **Color contrast** минимум 4.5:1 ratio
- **Focus indicators** за всички focusable елементи
- **Skip links** за навигация

### Тестове за достъпност
```bash
# Инсталиране на axe-core
npm install --save-dev @axe-core/playwright

# Стартиране на accessibility тестове
npm run test:a11y
```

## 🌐 Деплой

### Netlify (Препоръчително)
1. Свърза репозиторията с Netlify
2. Build command: `npm run build`
3. Publish directory: `dist`
4. Environment variables: няма нужда

### Vercel
1. Свърза репозиторията с Vercel
2. Framework preset: Vite
3. Build command: `npm run build`
4. Output directory: `dist`

### Manual Deploy
```bash
# Build проекта
npm run build

# Качи съдържанието на dist/ папката на сървъра
```

## 📈 Analytics и Monitoring

### Препоръчителни инструменти
- **Google Analytics 4** за уеб аналитика
- **Google PageSpeed Insights** за производителност
- **Sentry** за error monitoring
- **Hotjar** за user behavior analysis

## 🔒 Сигурност

### Best Practices
- **HTTPS only** за production
- **Content Security Policy** заглавки
- **CORS** правилна конфигурация
- **Input validation** за всички форми

## 📞 Поддръжка

### Контакти в кода
Всички контактни данни се намират в:
- `/components/data/contactData.ts`
- `/components/ContactSection.tsx`
- `/components/Footer.tsx`

### За въпроси и поддръжка
- **Email**: info@advelo.bg
- **Телефон**: +359 XXX XXX XXX
- **Адрес**: София, България

## 📄 Лиценз

Този проект е собственост на Advelo EOOD. Всички права запазени.

---

**Версия**: 1.0.0  
**Последна актуализация**: Януари 2025  
**Статус**: Production Ready ✅