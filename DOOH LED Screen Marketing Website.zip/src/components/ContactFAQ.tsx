import { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "./ui/card";
import { ChevronDown, ChevronUp, HelpCircle } from "lucide-react";

const faqData = [
  {
    question: "Колко време отнема настройката на кампанията?",
    answer: "Обикновено кампанията може да започне в рамките на 3-5 работни дни след одобрение на съдържанието и подписване на договора. За спешни случаи можем да осигурим по-бързо стартиране."
  },
  {
    question: "Какви са минималните изисквания за кампанията?",
    answer: "Минималната продължителност на кампанията е 1 седмица. Препоръчваме поне 10 LED екрана за оптимален обхват. Съдържанието трябва да бъде във видео формат с разделителна способност 1920x1080."
  },
  {
    question: "Мога ли да проследявам кампанията в реално време?",
    answer: "Да, осигуряваме GPS проследяване в реално време и детайлна аналитика. Ще получавате ежедневни отчети с данни за маршрутите, импресиите и демографските данни на аудиторията."
  },
  {
    question: "Как се определя цената на кампанията?",
    answer: "Цената зависи от броя на екраните, продължителността на кампанията и избраните маршрути. Нашият CPM (цена за 1000 показвания) е 47% по-евтин от традиционните билборди при значително по-добри резултати."
  },
  {
    question: "Какъв тип съдържание мога да показвам?",
    answer: "Поддържаме видео реклами (MP4), анимирани банери (GIF) и статични изображения (PNG/JPG). Съдържанието трябва да отговаря на стандартите за външна реклама и да бъде одобрено от нашия екип."
  },
  {
    question: "Има ли гаранция за резултатите?",
    answer: "Да, гарантираме минимален брой импресии според договорения план. Ако не постигнем целите показатели, предлагаме безплатна оптимизация или компенсация в следващата кампания."
  },
  {
    question: "Мога ли да променя съдържанието по време на кампанията?",
    answer: "Абсолютно! Една от най-големите предимства на нашата система е гъвкавостта. Можете да актуализирате съдържанието дистанционно без допълнителни разходи, което е невъзможно при традиционните билборди."
  },
  {
    question: "Покривате ли цяла София или само определени райони?",
    answer: "Покриваме цялата София и околностите ѝ чрез нашето партньорство с Yellow Taxi. Нашите маршрути включват центъра, бизнес зоните, търговските центрове, летището и жилищните квартали."
  }
];

interface FAQItemProps {
  question: string;
  answer: string;
  isOpen: boolean;
  onToggle: () => void;
}

function FAQItem({ question, answer, isOpen, onToggle }: FAQItemProps) {
  return (
    <Card className="dark-glass border-border hover:border-primary/50 transition-all duration-300 h-fit">
      <CardHeader 
        className="pb-3 cursor-pointer"
        onClick={onToggle}
      >
        <CardTitle className="text-foreground text-lg flex items-center justify-between group">
          <span className="group-hover:text-primary transition-colors">{question}</span>
          <div className="p-2 bg-primary/20 rounded-lg group-hover:bg-primary/30 transition-colors">
            {isOpen ? (
              <ChevronUp className="h-5 w-5 text-primary" />
            ) : (
              <ChevronDown className="h-5 w-5 text-primary" />
            )}
          </div>
        </CardTitle>
      </CardHeader>
      
      {isOpen && (
        <CardContent className="pt-0 pb-6">
          <div className="text-muted-foreground leading-relaxed pl-4 border-l-2 border-primary/30">
            {answer}
          </div>
        </CardContent>
      )}
    </Card>
  );
}

export function ContactFAQ() {
  const [openItems, setOpenItems] = useState<number[]>([]);

  const toggleItem = (index: number) => {
    setOpenItems(prev => 
      prev.includes(index) 
        ? prev.filter(i => i !== index)
        : [...prev, index]
    );
  };

  return (
    <div className="fade-in-up">
      <div className="text-center mb-8 lg:mb-12">
        <div className="flex items-center justify-center mb-6">
          <div className="w-20 h-px bg-gradient-to-r from-transparent via-primary to-transparent"></div>
          <div className="px-8">
            <div className="p-4 dark-glass rounded-full border border-primary/30">
              <HelpCircle className="h-8 w-8 text-primary" />
            </div>
          </div>
          <div className="w-20 h-px bg-gradient-to-r from-primary via-primary to-transparent"></div>
        </div>
        <h3 className="text-2xl md:text-3xl lg:text-4xl text-foreground font-bold mb-4">
          Често задавани <span className="text-primary">въпроси</span>
        </h3>
        <p className="text-lg text-muted-foreground max-w-2xl mx-auto leading-relaxed">
          Намерете отговори на най-често задаваните въпроси относно нашите услуги
        </p>
      </div>

      <div className="max-w-6xl mx-auto">
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4 lg:gap-6 xl:gap-8">
          {faqData.map((faq, index) => (
            <FAQItem
              key={index}
              question={faq.question}
              answer={faq.answer}
              isOpen={openItems.includes(index)}
              onToggle={() => toggleItem(index)}
            />
          ))}
        </div>
      </div>

      <div className="text-center mt-12 p-6 dark-glass-strong rounded-lg border border-primary/30">
        <div className="flex items-center justify-center mb-4">
          <div className="p-3 bg-primary/20 rounded-full">
            <HelpCircle className="h-6 w-6 text-primary" />
          </div>
        </div>
        <h4 className="text-xl text-foreground font-semibold mb-2">
          Не намерихте отговора на вашия въпрос?
        </h4>
        <p className="text-muted-foreground mb-4">
          Свържете се с нас и ние ще отговорим на всички ваши въпроси в рамките на 24 часа.
        </p>
        <div className="flex flex-col sm:flex-row gap-4 justify-center">
          <a 
            href="mailto:contact@advelo.bg" 
            className="flex items-center justify-center space-x-2 px-6 py-3 bg-primary text-primary-foreground rounded-lg hover:bg-primary/90 transition-colors font-semibold"
            aria-label="Изпрати имейл до contact@advelo.bg"
          >
            <span>contact@advelo.bg</span>
          </a>
          <a 
            href="tel:+359889792777" 
            className="flex items-center justify-center space-x-2 px-6 py-3 border border-primary text-primary rounded-lg hover:bg-primary/10 transition-colors font-semibold"
            aria-label="Обади се на +359 88 979 2777"
          >
            <span>+359 88 979 2777</span>
          </a>
        </div>
      </div>
    </div>
  );
}