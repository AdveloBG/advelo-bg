import { useState } from "react";
import { Button } from "./ui/button";
import { Input } from "./ui/input";
import { Label } from "./ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "./ui/select";
import { Card, CardContent, CardHeader, CardTitle } from "./ui/card";
import { 
  Mail, 
  Phone, 
  MapPin, 
  Send, 
  MessageCircle,
  Clock,
  CheckCircle,
  Star,
  Shield,
  Zap
} from "lucide-react";
import { toast } from "sonner@2.0.3";
import { ContactFAQ } from "./ContactFAQ";
import { nextSteps, contactInfo } from "./data/contactData";
import { ThemeAwareLogo } from "./ThemeAwareLogo";
import { submitContactForm, isValidEmail, isValidBulgarianPhone, formatPhoneNumber, trackEvent } from "../utils/api";

export function ContactSection() {
  const [formData, setFormData] = useState({
    email: "",
    name: "",
    phoneNumber: "",
    company: "",
    numberOfScreens: "",
    period: "",
    message: ""
  });

  const [isSubmitting, setIsSubmitting] = useState(false);
  const [errors, setErrors] = useState<Record<string, string>>({});

  const handleInputChange = (field: string, value: string) => {
    setFormData(prev => ({
      ...prev,
      [field]: value
    }));
  };

  const validateForm = () => {
    const newErrors: Record<string, string> = {};

    if (!formData.name.trim()) {
      newErrors.name = "Моля, въведете вашето име";
    }

    if (!formData.email.trim()) {
      newErrors.email = "Моля, въведете имейл адрес";
    } else if (!isValidEmail(formData.email)) {
      newErrors.email = "Моля, въведете валиден имейл адрес";
    }

    if (!formData.phoneNumber.trim()) {
      newErrors.phoneNumber = "Моля, въведете телефонен номер";
    } else if (!isValidBulgarianPhone(formData.phoneNumber)) {
      newErrors.phoneNumber = "Моля, въведете валиден български телефонен номер";
    }

    if (!formData.company.trim()) {
      newErrors.company = "Моля, въведете името на фирмата";
    }

    if (!formData.numberOfScreens) {
      newErrors.numberOfScreens = "Моля, изберете брой екрани";
    }

    if (!formData.period) {
      newErrors.period = "Моля, изберете период на кампанията";
    }

    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!validateForm()) {
      toast.error("Моля, коригирайте грешките във формата");
      return;
    }

    setIsSubmitting(true);

    try {
      // Track form submission attempt
      trackEvent('contact_form_submit', {
        screens: formData.numberOfScreens,
        period: formData.period,
        hasMessage: !!formData.message.trim()
      });

      const result = await submitContactForm({
        name: formData.name,
        email: formData.email,
        phone: formatPhoneNumber(formData.phoneNumber),
        company: formData.company,
        screens: formData.numberOfScreens,
        period: formData.period,
        message: formData.message || `Заявка за ${formData.numberOfScreens} за период от ${formData.period}`
      });

      if (result.success) {
        toast.success(result.data || "Благодарим ви! Ще се свържем с вас в рамките на 24 часа.");
        
        // Track successful submission
        trackEvent('contact_form_success', {
          screens: formData.numberOfScreens,
          period: formData.period
        });

        // Reset form
        setFormData({
          email: "",
          name: "",
          phoneNumber: "",
          company: "",
          numberOfScreens: "",
          period: "",
          message: ""
        });
        setErrors({});
      } else {
        toast.error(result.error || "Възникна грешка при изпращането. Моля, опитайте отново.");
        
        // Track failed submission
        trackEvent('contact_form_error', {
          error: result.error
        });
      }
    } catch (error) {
      console.error('Form submission error:', error);
      toast.error("Възникна грешка при изпращането. Моля, опитайте отново.");
      
      trackEvent('contact_form_error', {
        error: 'Network error'
      });
    } finally {
      setIsSubmitting(false);
    }
  };

  const isFormValid = formData.name.trim() && 
                    formData.email.trim() && 
                    formData.phoneNumber.trim() && 
                    formData.company.trim() && 
                    formData.numberOfScreens && 
                    formData.period;

  const getIcon = (type: string) => {
    switch(type) {
      case 'email': return Mail;
      case 'phone': return Phone;
      case 'location': return MapPin;
      case 'hours': return Clock;
      default: return Mail;
    }
  };

  const guaranteeFeatures = [
    { icon: Shield, title: "Гаранция за резултат", desc: "Измерими резултати или безплатна оптимизация" },
    { icon: Clock, title: "24/7 поддръжка", desc: "Техническа поддръжка и мониторинг на кампаниите" },
    { icon: CheckCircle, title: "GPS проследяване", desc: "Реално време мониторинг и детайлна аналитика" }
  ];

  return (
    <section id="contact" className="py-12 lg:py-16 xl:py-20 section-pattern-1 relative">
      <div className="container-responsive">
        {/* Enhanced header with better mobile spacing */}
        <div className="text-center mb-8 lg:mb-12 xl:mb-16 fade-in-up">
          <div className="flex items-center justify-center mb-4 lg:mb-6">
            <div className="w-12 lg:w-20 h-px bg-gradient-to-r from-transparent via-primary to-transparent"></div>
            <div className="px-4 lg:px-8">
              <div className="p-3 lg:p-4 dark-glass rounded-full border border-primary/30">
                <MessageCircle className="h-6 lg:h-8 w-6 lg:w-8 text-primary" />
              </div>
            </div>
            <div className="w-12 lg:w-20 h-px bg-gradient-to-r from-primary via-primary to-transparent"></div>
          </div>
          
          <h2 className="text-2xl sm:text-3xl lg:text-4xl xl:text-5xl text-foreground mb-4 lg:mb-6 font-bold">
            Получете вашата
            <span className="text-primary block mt-1 lg:mt-2">персонализирана оферта</span>
          </h2>
          <p className="text-muted-foreground max-w-3xl mx-auto leading-relaxed px-4">
            Готови сте за революция в рекламата? Попълнете формата по-долу и ще 
            създадем персонализирано предложение за кампания специално за вашия бизнес.
          </p>
        </div>

        <div className="max-w-7xl mx-auto">
          {/* Mobile Layout: Why Advelo First */}
          <div className="lg:hidden mb-8">
            <Card className="dark-glass border-primary/30 card-hover slide-in-up">
              <CardHeader className="pb-4">
                <CardTitle className="text-foreground flex items-center justify-center">
                  <div className="p-3 bg-primary/20 rounded-lg mr-3">
                    <Star className="h-5 w-5 text-primary" />
                  </div>
                  Защо ADVELO?
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                {guaranteeFeatures.map((feature, index) => (
                  <div key={index} className="flex items-start space-x-4 p-4 bg-secondary/30 rounded-lg border border-border hover:border-primary/30 transition-all duration-300">
                    <div className="p-2 bg-primary/20 rounded-lg shrink-0 mt-0.5">
                      <feature.icon className="h-4 w-4 text-primary" />
                    </div>
                    <div className="min-w-0">
                      <div className="text-foreground font-semibold mb-2">{feature.title}</div>
                      <div className="text-muted-foreground leading-relaxed">{feature.desc}</div>
                    </div>
                  </div>
                ))}
              </CardContent>
            </Card>
          </div>

          {/* Desktop: 3-Column Equal Height Layout | Mobile: Contact Form Second */}
          <div className="lg:grid lg:grid-cols-3 lg:gap-8 xl:gap-12 lg:items-stretch space-y-8 lg:space-y-0">
            
            {/* Desktop Left: Why Advelo | Mobile: Hidden (already shown above) */}
            <div className="hidden lg:block slide-in-left">
              <Card className="dark-glass border-primary/30 card-hover h-full flex flex-col">
                <CardHeader className="pb-5">
                  <CardTitle className="text-foreground flex items-center justify-center text-xl">
                    <div className="p-3 bg-primary/20 rounded-lg mr-3">
                      <Star className="h-6 w-6 text-primary" />
                    </div>
                    Защо ADVELO?
                  </CardTitle>
                </CardHeader>
                <CardContent className="space-y-5 flex-1 flex flex-col justify-center px-6">
                  {guaranteeFeatures.map((feature, index) => (
                    <div key={index} className="flex items-start space-x-4 p-4 bg-secondary/30 rounded-lg border border-border hover:border-primary/30 transition-all duration-300">
                      <div className="p-2 bg-primary/20 rounded-lg shrink-0 mt-0.5">
                        <feature.icon className="h-5 w-5 text-primary" />
                      </div>
                      <div className="min-w-0">
                        <div className="text-foreground font-semibold mb-2">{feature.title}</div>
                        <div className="text-muted-foreground leading-relaxed">{feature.desc}</div>
                      </div>
                    </div>
                  ))}
                </CardContent>
              </Card>
            </div>

            {/* Center: Enhanced Contact Form with Fixed Dropdown Issues */}
            <div className="slide-in-up relative">
              {/* Enhanced glow effect for the contact form */}
              <div className="absolute -inset-4 bg-gradient-to-r from-primary/20 via-primary/30 to-primary/20 rounded-3xl blur-xl opacity-60 animate-pulse"></div>
              <div className="absolute -inset-2 bg-gradient-to-r from-primary/10 to-primary/5 rounded-2xl"></div>
              
              <Card className="relative dark-glass border-primary/50 card-hover h-full flex flex-col shadow-2xl shadow-primary/20 ring-1 ring-primary/30 overflow-hidden">
                {/* Fixed Header with Proper Containment */}
                <CardHeader className="pb-4 lg:pb-6 text-center px-6 pt-6">
                  <div className="flex items-center justify-center mb-4 max-w-full">
                    <div className="flex items-center space-x-3 max-w-full">
                      <ThemeAwareLogo 
                        className="h-8 lg:h-10 w-auto flex-shrink-0"
                        alt="Advelo Logo"
                      />
                      <div className="w-px h-8 lg:h-10 bg-primary flex-shrink-0"></div>
                      <div className="p-2 bg-primary/20 rounded-lg flex-shrink-0">
                        <MessageCircle className="h-5 lg:h-6 w-5 lg:w-6 text-primary" />
                      </div>
                    </div>
                  </div>
                  <CardTitle className="text-lg sm:text-xl lg:text-2xl text-foreground">
                    Заявка за персонализирана оферта
                  </CardTitle>
                  <p className="text-muted-foreground mt-2 text-sm lg:text-base">
                    Попълнете данните и ще получите оферта в рамките на 24 часа
                  </p>
                </CardHeader>
                
                <CardContent className="flex-1 flex flex-col px-6 pb-6">
                  <form onSubmit={handleSubmit} className="space-y-4 flex-1 flex flex-col justify-between">
                    {/* 2-Column Grid Layout for Desktop, Single Column for Mobile */}
                    <div className="space-y-4">
                      {/* Row 1: Name and Email */}
                      <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
                        <div className="space-y-2">
                          <Label htmlFor="name" className="text-foreground font-medium text-sm">Име и фамилия *</Label>
                          <Input
                            id="name"
                            type="text"
                            value={formData.name}
                            onChange={(e) => handleInputChange("name", e.target.value)}
                            className="bg-input border-border text-foreground focus:border-primary hover:border-primary/50 transition-all duration-300 h-11"
                            placeholder="Иван Петров"
                            required
                          />
                        </div>
                        <div className="space-y-2">
                          <Label htmlFor="email" className="text-foreground font-medium text-sm">Имейл адрес *</Label>
                          <Input
                            id="email"
                            type="email"
                            value={formData.email}
                            onChange={(e) => handleInputChange("email", e.target.value)}
                            className="bg-input border-border text-foreground focus:border-primary hover:border-primary/50 transition-all duration-300 h-11"
                            placeholder="ivan@company.bg"
                            required
                          />
                        </div>
                      </div>

                      {/* Row 2: Phone and Company */}
                      <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
                        <div className="space-y-2">
                          <Label htmlFor="phone" className="text-foreground font-medium text-sm">Телефонен номер *</Label>
                          <Input
                            id="phone"
                            type="tel"
                            value={formData.phoneNumber}
                            onChange={(e) => handleInputChange("phoneNumber", e.target.value)}
                            className="bg-input border-border text-foreground focus:border-primary hover:border-primary/50 transition-all duration-300 h-11"
                            placeholder="+359 88 979 2777"
                            required
                          />
                        </div>
                        <div className="space-y-2">
                          <Label htmlFor="company" className="text-foreground font-medium text-sm">Име на фирмата *</Label>
                          <Input
                            id="company"
                            type="text"
                            value={formData.company}
                            onChange={(e) => handleInputChange("company", e.target.value)}
                            className="bg-input border-border text-foreground focus:border-primary hover:border-primary/50 transition-all duration-300 h-11"
                            placeholder="Вашата фирма ЕООД"
                            required
                          />
                        </div>
                      </div>

                      {/* Row 3: Screens and Period - Fixed Dropdown Alignment and Text Display */}
                      <div className="grid grid-cols-1 lg:grid-cols-2 gap-4 items-end">
                        <div className="space-y-2">
                          <Label className="text-foreground font-medium text-sm">Брой екрани *</Label>
                          <Select 
                            value={formData.numberOfScreens} 
                            onValueChange={(value) => handleInputChange("numberOfScreens", value)}
                            required
                          >
                            <SelectTrigger className="bg-input border-border text-foreground focus:border-primary hover:border-primary/50 transition-all duration-300 h-11 w-full flex items-center justify-between px-3 text-sm">
                              <SelectValue placeholder="Брой екрани" className="truncate text-left flex-1 min-w-0" />
                            </SelectTrigger>
                            <SelectContent className="bg-popover border-border min-w-[200px] z-50" align="start">
                              <SelectItem 
                                value="10-20" 
                                className="text-popover-foreground hover:bg-primary/20 px-3 py-2 cursor-pointer"
                              >
                                <span className="block">10-20 екрана</span>
                              </SelectItem>
                              <SelectItem 
                                value="20-30" 
                                className="text-popover-foreground hover:bg-primary/20 px-3 py-2 cursor-pointer"
                              >
                                <span className="block">20-30 екрана</span>
                              </SelectItem>
                              <SelectItem 
                                value="50+" 
                                className="text-popover-foreground hover:bg-primary/20 px-3 py-2 cursor-pointer"
                              >
                                <span className="block">50+ екрана</span>
                              </SelectItem>
                            </SelectContent>
                          </Select>
                        </div>
                        <div className="space-y-2">
                          <Label className="text-foreground font-medium text-sm">Период на кампанията *</Label>
                          <Select 
                            value={formData.period} 
                            onValueChange={(value) => handleInputChange("period", value)}
                            required
                          >
                            <SelectTrigger className="bg-input border-border text-foreground focus:border-primary hover:border-primary/50 transition-all duration-300 h-11 w-full flex items-center justify-between px-3 text-sm">
                              <SelectValue placeholder="Период" className="truncate text-left flex-1 min-w-0" />
                            </SelectTrigger>
                            <SelectContent className="bg-popover border-border min-w-[200px] z-50" align="start">
                              <SelectItem 
                                value="3-months" 
                                className="text-popover-foreground hover:bg-primary/20 px-3 py-2 cursor-pointer"
                              >
                                <span className="block">3 месеца</span>
                              </SelectItem>
                              <SelectItem 
                                value="6-months" 
                                className="text-popover-foreground hover:bg-primary/20 px-3 py-2 cursor-pointer"
                              >
                                <span className="block">6 месеца</span>
                              </SelectItem>
                              <SelectItem 
                                value="12-months" 
                                className="text-popover-foreground hover:bg-primary/20 px-3 py-2 cursor-pointer"
                              >
                                <span className="block">12 месеца</span>
                              </SelectItem>
                            </SelectContent>
                          </Select>
                        </div>
                      </div>
                    </div>

                    <div className="mt-auto pt-6">
                      <Button 
                        type="submit" 
                        disabled={!isFormValid || isSubmitting}
                        className="w-full bg-primary text-primary-foreground hover:bg-primary/90 py-4 font-semibold relative overflow-hidden transition-all duration-300 pulse-glow ring-2 ring-primary/50 shadow-lg shadow-primary/30"
                      >
                      {isSubmitting ? (
                        <>
                          <div className="animate-spin rounded-full h-4 w-4 border-2 border-primary-foreground border-t-transparent mr-3"></div>
                          Обработва се...
                        </>
                      ) : (
                        <>
                          Получете персонализирана оферта
                          <Send className="ml-2 h-4 w-4" />
                        </>
                      )}
                      </Button>
                    </div>
                  </form>
                </CardContent>
              </Card>
            </div>

            {/* Desktop Right: Quick Contact with Better Content Distribution | Mobile: Third */}
            <div className="slide-in-right">
              <Card className="dark-glass border-primary/30 card-hover h-full flex flex-col">
                <CardHeader className="pb-5">
                  <CardTitle className="text-foreground flex items-center justify-center text-xl">
                    <div className="p-3 bg-primary/20 rounded-lg mr-3">
                      <Phone className="h-6 w-6 text-primary" />
                    </div>
                    Бърз контакт
                  </CardTitle>
                </CardHeader>
                <CardContent className="space-y-5 flex-1 flex flex-col px-6">
                  {/* Contact Information */}
                  <div className="space-y-4 flex-1">
                    {contactInfo.slice(0, 2).map((info, index) => {
                      const IconComponent = getIcon(info.type);
                      const getHref = (type: string, value: string) => {
                        switch(type) {
                          case 'email': return `mailto:${value}`;
                          case 'phone': return `tel:${value}`;
                          default: return '#';
                        }
                      };
                      
                      return (
                        <a 
                          key={index} 
                          href={getHref(info.type, info.value)}
                          className="flex items-center space-x-4 p-4 bg-secondary/50 rounded-lg border border-border hover:border-primary/30 transition-all duration-300 group no-underline cursor-pointer hover:bg-secondary/70 hover:scale-[1.02]"
                          aria-label={info.type === 'email' ? `Изпрати имейл до ${info.value}` : `Обади се на ${info.value}`}
                        >
                          <div className="p-2 bg-primary/20 rounded-lg shrink-0 group-hover:bg-primary/30 transition-colors">
                            <IconComponent className="h-5 w-5 text-primary" />
                          </div>
                          <span className="text-foreground font-medium group-hover:text-primary transition-colors">{info.value}</span>
                        </a>
                      );
                    })}
                  </div>

                  {/* Additional Content to Fill Space */}
                  <div className="space-y-4">
                    <div className="p-4 bg-gradient-to-r from-primary/10 to-transparent rounded-lg border border-primary/20">
                      <div className="text-primary font-semibold mb-2">Отговаряме в рамките на 2 часа</div>
                      <div className="text-muted-foreground">През работни дни 9:00-18:00</div>
                    </div>
                    
                    <div className="p-4 bg-secondary/30 rounded-lg border border-border">
                      <div className="flex items-center space-x-3 mb-2">
                        <div className="p-1 bg-primary/20 rounded">
                          <Clock className="h-4 w-4 text-primary" />
                        </div>
                        <div className="text-foreground font-medium">Безплатна консултация</div>
                      </div>
                      <div className="text-muted-foreground text-sm">
                        Получете експертен съвет за вашата кампания
                      </div>
                    </div>

                    <div className="p-4 bg-secondary/30 rounded-lg border border-border">
                      <div className="flex items-center space-x-3 mb-2">
                        <div className="p-1 bg-primary/20 rounded">
                          <CheckCircle className="h-4 w-4 text-primary" />
                        </div>
                        <div className="text-foreground font-medium">Гарантирана доставка</div>
                      </div>
                      <div className="text-muted-foreground text-sm">
                        Персонализирана оферта до 24 часа
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </div>
          </div>

          {/* Quick Facts - Below Contact Form on Desktop, Fourth on Mobile */}
          <div className="mt-8 lg:mt-12 max-w-5xl mx-auto">
            <Card className="dark-glass border-primary/30 card-hover slide-in-up">
              <CardHeader className="pb-5">
                <CardTitle className="text-foreground flex items-center justify-center text-xl lg:text-2xl">
                  <div className="p-3 bg-primary/20 rounded-lg mr-3">
                    <Zap className="h-6 w-6 text-primary" />
                  </div>
                  Бързи факти
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-6">
                <div className="grid grid-cols-2 lg:grid-cols-4 gap-4 lg:gap-6">
                  <div className="text-center p-4 lg:p-6 bg-secondary/30 rounded-lg border border-border hover:border-primary/30 transition-all duration-300">
                    <div className="text-primary font-bold mb-1 text-lg lg:text-2xl">6.2M</div>
                    <div className="text-muted-foreground text-sm lg:text-base">месечни импресии</div>
                  </div>
                  <div className="text-center p-4 lg:p-6 bg-secondary/30 rounded-lg border border-border hover:border-primary/30 transition-all duration-300">
                    <div className="text-primary font-bold mb-1 text-lg lg:text-2xl">47%</div>
                    <div className="text-muted-foreground text-sm lg:text-base">по-евтино</div>
                  </div>
                  <div className="text-center p-4 lg:p-6 bg-secondary/30 rounded-lg border border-border hover:border-primary/30 transition-all duration-300">
                    <div className="text-primary font-bold mb-1 text-lg lg:text-2xl">24/7</div>
                    <div className="text-muted-foreground text-sm lg:text-base">мониторинг</div>
                  </div>
                  <div className="text-center p-4 lg:p-6 bg-secondary/30 rounded-lg border border-border hover:border-primary/30 transition-all duration-300">
                    <div className="text-primary font-bold mb-1 text-lg lg:text-2xl">120+</div>
                    <div className="text-muted-foreground text-sm lg:text-base">локации/ден</div>
                  </div>
                </div>
                <div className="mt-6 pt-5 border-t border-border">
                  <div className="text-center">
                    <div className="text-primary font-semibold mb-2 text-lg lg:text-xl">🏆 #1 в България</div>
                    <div className="text-muted-foreground text-sm lg:text-base">Първата мобилна LED реклама платформа</div>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        </div>

        {/* FAQ Section - Better mobile spacing */}
        <div className="mt-12 lg:mt-16 xl:mt-20">
          <ContactFAQ />
        </div>
      </div>
    </section>
  );
}