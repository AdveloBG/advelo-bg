import { Component, ErrorInfo, ReactNode } from 'react';
import { AlertTriangle, RefreshCw, Home, Mail } from 'lucide-react';
import { Button } from './ui/button';
import { Card, CardContent, CardHeader, CardTitle } from './ui/card';

interface Props {
  children: ReactNode;
}

interface State {
  hasError: boolean;
  error?: Error;
  errorInfo?: ErrorInfo;
}

export class ErrorBoundary extends Component<Props, State> {
  constructor(props: Props) {
    super(props);
    this.state = { hasError: false };
  }

  public static getDerivedStateFromError(error: Error): State {
    return { 
      hasError: true,
      error 
    };
  }

  public componentDidCatch(error: Error, errorInfo: ErrorInfo) {
    console.error('ErrorBoundary caught an error:', error, errorInfo);
    
    this.setState({
      error,
      errorInfo
    });

    // Log error to analytics service if available
    if (typeof window !== 'undefined' && window.gtag) {
      window.gtag('event', 'exception', {
        description: error.toString(),
        fatal: false
      });
    }
  }

  private handleReload = () => {
    window.location.reload();
  };

  private handleGoHome = () => {
    window.location.href = '/';
  };

  public render() {
    if (this.state.hasError) {
      return (
        <div className="min-h-screen bg-background text-foreground flex items-center justify-center p-4">
          <div className="max-w-2xl mx-auto">
            <Card className="dark-glass border-destructive/30">
              <CardHeader className="text-center pb-4">
                <div className="mx-auto mb-4 p-4 bg-destructive/20 rounded-full w-fit">
                  <AlertTriangle className="h-12 w-12 text-destructive" />
                </div>
                <CardTitle className="text-2xl lg:text-3xl text-foreground mb-2">
                  Възникна техническа грешка
                </CardTitle>
                <p className="text-muted-foreground">
                  Извиняваме се за неудобството. Нещо се обърка, но работим по решаването на проблема.
                </p>
              </CardHeader>
              
              <CardContent className="space-y-6">
                {/* Error Actions */}
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  <Button 
                    onClick={this.handleReload}
                    className="bg-primary text-primary-foreground hover:bg-primary/90 flex items-center justify-center gap-2"
                  >
                    <RefreshCw className="h-4 w-4" />
                    Презареди страницата
                  </Button>
                  
                  <Button 
                    variant="outline"
                    onClick={this.handleGoHome}
                    className="border-border text-foreground hover:bg-secondary flex items-center justify-center gap-2"
                  >
                    <Home className="h-4 w-4" />
                    Начална страница
                  </Button>
                </div>
                
                {/* Contact Information */}
                <div className="p-4 bg-secondary/30 rounded-lg border border-border">
                  <div className="text-center">
                    <p className="text-foreground font-medium mb-3">
                      Ако проблемът продължава, свържете се с нас:
                    </p>
                    <div className="flex flex-col sm:flex-row gap-4 justify-center">
                      <a 
                        href="mailto:info@advelo.bg" 
                        className="flex items-center justify-center gap-2 text-primary hover:text-primary/80 transition-colors"
                      >
                        <Mail className="h-4 w-4" />
                        info@advelo.bg
                      </a>
                      <a 
                        href="tel:+359889792777" 
                        className="flex items-center justify-center gap-2 text-primary hover:text-primary/80 transition-colors"
                      >
                        <svg className="h-4 w-4" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                          <path d="M22 16.92v3a2 2 0 0 1-2.18 2 19.79 19.79 0 0 1-8.63-3.07 19.5 19.5 0 0 1-6-6 19.79 19.79 0 0 1-3.07-8.67A2 2 0 0 1 4.11 2h3a2 2 0 0 1 2 1.72 12.84 12.84 0 0 0 .7 2.81 2 2 0 0 1-.45 2.11L8.09 9.91a16 16 0 0 0 6 6l1.27-1.27a2 2 0 0 1 2.11-.45 12.84 12.84 0 0 0 2.81.7A2 2 0 0 1 22 16.92z" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
                        </svg>
                        +359 88 979 2777
                      </a>
                    </div>
                  </div>
                </div>
                
                {/* Development Error Details (only in development) */}
                {process.env.NODE_ENV === 'development' && this.state.error && (
                  <details className="mt-6">
                    <summary className="cursor-pointer text-sm text-muted-foreground hover:text-foreground">
                      Техническа информация (за разработчици)
                    </summary>
                    <div className="mt-3 p-4 bg-destructive/10 border border-destructive/20 rounded-lg text-sm">
                      <div className="font-mono text-destructive">
                        <strong>Error:</strong> {this.state.error.message}
                      </div>
                      {this.state.error.stack && (
                        <pre className="mt-2 text-xs text-muted-foreground overflow-x-auto whitespace-pre-wrap">
                          {this.state.error.stack}
                        </pre>
                      )}
                    </div>
                  </details>
                )}
                
                {/* Branding */}
                <div className="text-center pt-4 border-t border-border">
                  <p className="text-xs text-muted-foreground">
                    Advelo - Мобилна LED реклама в България
                  </p>
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
      );
    }

    return this.props.children;
  }
}

// Type declaration for gtag (Google Analytics)
declare global {
  interface Window {
    gtag?: (
      command: 'config' | 'set' | 'event',
      targetId: string,
      config?: Record<string, any>
    ) => void;
  }
}