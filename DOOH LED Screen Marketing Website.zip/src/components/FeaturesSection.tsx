import { Card, CardContent } from "./ui/card";
import { features, comparisonData, whyAdvelo, keyStats } from "./data/featuresData";
import { CheckCircle, XCircle, Award, Zap, Target } from "lucide-react";
import { ImageWithFallback } from './figma/ImageWithFallback';

export function FeaturesSection() {
  return (
    <section id="features" className="py-16 lg:py-20 bg-gradient-to-b from-dark-gray to-background circuit-pattern relative">
      {/* Background DOOH image */}
      <div className="absolute inset-0 opacity-5">
        <ImageWithFallback
          src="https://images.unsplash.com/photo-1675700189677-b6f505c214a2?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxvdXRkb29yJTIwZGlnaXRhbCUyMHNpZ25hZ2UlMjBkaXNwbGF5fGVufDF8fHx8MTc1NTYwNTIwN3ww&ixlib=rb-4.1.0&q=80&w=1080"
          alt="Outdoor Digital Signage"
          className="w-full h-full object-cover"
        />
      </div>

      <div className="container-responsive relative z-10">
        
        {/* Enhanced header with symmetrical design */}
        <div className="text-center mb-12 lg:mb-16 fade-in-up">
          <div className="flex items-center justify-center mb-6">
            <div className="w-16 h-px bg-gradient-to-r from-transparent via-primary to-transparent"></div>
            <div className="px-6">
              <div className="p-3 dark-glass rounded-full border border-primary/30">
                <Award className="h-8 w-8 text-primary" />
              </div>
            </div>
            <div className="w-16 h-px bg-gradient-to-r from-primary via-primary to-transparent"></div>
          </div>
          
          <h2 className="text-3xl md:text-4xl lg:text-5xl text-foreground mb-6 font-bold">
            Защо да изберете
            <span className="text-primary block mt-2">ADVELO</span>
          </h2>
          <p className="text-muted-foreground max-w-2xl mx-auto leading-relaxed">
            Патентована мобилна LED технология с ексклузивно партньорство с Yellow такси.
          </p>
        </div>

        {/* Clean, Compact Features Grid */}
        <div className="mb-16 lg:mb-20">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 max-w-5xl mx-auto">
            {features.slice(0, 6).map((feature, index) => (
              <div 
                key={index} 
                className="group fade-in-up relative"
                style={{animationDelay: `${index * 0.1}s`}}
              >
                <Card className={`h-full dark-glass border-border hover:border-primary/50 transition-all duration-300 group-hover:shadow-lg group-hover:shadow-primary/10 ${
                  feature.highlight ? 'border-primary/30 shadow-md shadow-primary/5' : ''
                }`}>
                  <CardContent className="p-6 h-full flex flex-col items-center text-center relative">
                    
                    {/* Number Badge - Fixed positioning */}
                    <div className="absolute -top-2 -right-2 z-10">
                      <div className={`w-7 h-7 rounded-full border-2 flex items-center justify-center text-xs font-bold transition-all duration-300 ${
                        feature.highlight 
                          ? 'bg-primary border-primary text-white shadow-lg shadow-primary/25' 
                          : 'bg-card border-primary text-primary group-hover:bg-primary group-hover:text-white group-hover:border-primary'
                      }`}>
                        {index + 1}
                      </div>
                    </div>

                    {/* Icon Container */}
                    <div className="mb-4">
                      <div className={`w-14 h-14 rounded-full flex items-center justify-center transition-all duration-300 ${
                        feature.highlight 
                          ? 'bg-primary/15 border-2 border-primary/30' 
                          : 'bg-primary/10 border-2 border-primary/20 group-hover:border-primary/40 group-hover:bg-primary/15'
                      }`}>
                        <feature.icon className={`h-7 w-7 transition-colors duration-300 ${
                          feature.highlight ? 'text-primary' : 'text-primary'
                        }`} />
                      </div>
                    </div>

                    {/* Feature Title */}
                    <h3 className="text-base font-semibold text-foreground leading-tight group-hover:text-primary transition-colors duration-300 max-w-[180px]">
                      {feature.title}
                    </h3>
                  </CardContent>
                </Card>
              </div>
            ))}
          </div>
        </div>

        {/* Streamlined Benefits Section - Removed duplicated content */}
        <div className="mb-16 lg:mb-20">
          <div className="dark-glass-strong rounded-2xl p-6 lg:p-8 border border-primary/30 relative overflow-hidden">
            <div className="absolute top-0 right-0 w-32 lg:w-64 h-32 lg:h-64 bg-gradient-to-bl from-primary/10 to-transparent rounded-full -translate-y-16 lg:-translate-y-32 translate-x-16 lg:translate-x-32"></div>
            
            <div className="relative z-10">
              <div className="text-center mb-8 lg:mb-12">
                <div className="flex items-center justify-center mb-4">
                  <div className="p-3 bg-primary/20 rounded-full mr-4">
                    <Target className="h-8 w-8 text-primary" />
                  </div>
                  <span className="text-primary font-semibold tracking-wide">КЛЮЧОВИ ПРЕДИМСТВА</span>
                </div>
                <h3 className="text-2xl md:text-3xl lg:text-4xl text-foreground font-bold">
                  Какво ни прави <span className="text-primary">уникални</span>
                </h3>
              </div>
              
              <div className="grid md:grid-cols-2 gap-8 lg:gap-12 items-center">
                <div className="space-y-6 slide-in-left">
                  {/* Unique benefits focused on patent, exclusivity, and innovation */}
                  {[
                    "Патентована технология от Българското патентно ведомство",
                    "Ексклузивен договор с Yellow такси - лидер в България", 
                    "Първата мобилна LED технология в страната",
                    "Плащане само за активно показване - без скрити такси"
                  ].map((item, index) => (
                    <div key={index} className="flex items-start space-x-4 fade-in-up" style={{animationDelay: `${index * 0.1}s`}}>
                      <div className="p-1 bg-primary/20 rounded-full mt-1 shrink-0">
                        <CheckCircle className="h-5 w-5 text-primary" />
                      </div>
                      <p className="text-muted-foreground leading-relaxed">{item}</p>
                    </div>
                  ))}
                </div>
                
                <div className="relative slide-in-right">
                  <div className="rounded-xl overflow-hidden relative">
                    <ImageWithFallback
                      src="https://images.unsplash.com/photo-1716577954932-00e2dd51c790?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxjYXIlMjBtb2JpbGUlMjBhZHZlcnRpc2luZyUyMHNjcmVlbnxlbnwxfHx8fDE3NTU2MDM5ODF8MA&ixlib=rb-4.1.0&q=80&w=1080"
                      alt="Mobile LED Advertising Technology"
                      className="w-full h-48 lg:h-64 object-cover"
                    />
                    <div className="absolute inset-0 bg-gradient-to-t from-black/70 via-transparent to-transparent"></div>
                    <div className="absolute bottom-4 left-4 image-overlay-text">
                      <div className="flex items-center space-x-2 mb-2">
                        <div className="p-1 bg-primary rounded">
                          <Award className="h-4 w-4 image-overlay-icon" />
                        </div>
                        <span className="text-sm font-semibold image-overlay-primary">Патентована технология</span>
                      </div>
                      <div className="text-xs opacity-90 flex items-center space-x-2">
                        <div className="w-2 h-2 bg-primary rounded-full pulse-glow"></div>
                        <span className="image-overlay-secondary">Първa в България</span>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* Enhanced Comparison Section */}
        <div className="mb-16 lg:mb-20">
          <div className="text-center mb-8 lg:mb-12">
            <div className="flex items-center justify-center mb-4">
              <div className="p-2 dark-glass rounded-lg mr-3">
                <Zap className="h-6 w-6 text-primary" />
              </div>
              <span className="text-primary font-semibold tracking-wide">СРАВНЕНИЕ</span>
            </div>
            <h3 className="text-2xl md:text-3xl lg:text-4xl text-foreground font-bold">
              <span className="text-primary">ADVELO</span> срещу традиционна реклама
            </h3>
          </div>
          
          <div className="grid lg:grid-cols-2 gap-8 lg:gap-12">
            {/* Advelo Advantages */}
            <div className="dark-glass rounded-2xl p-6 lg:p-8 border border-primary/50 relative overflow-hidden slide-in-left">
              <div className="absolute top-0 right-0 w-32 h-32 bg-gradient-to-bl from-primary/20 to-transparent rounded-full -translate-y-16 translate-x-16"></div>
              
              <div className="text-center mb-6 relative z-10">
                <div className="w-16 h-16 mx-auto mb-4 rounded-full bg-gradient-to-br from-primary/20 to-primary/10 flex items-center justify-center">
                  <Award className="h-8 w-8 text-primary" />
                </div>
                <div className="text-2xl font-bold text-primary mb-2">ADVELO</div>
                <div className="text-muted-foreground">Мобилна LED реклама</div>
              </div>
              <div className="space-y-4 relative z-10">
                {comparisonData.advelo.map((item, index) => (
                  <div key={index} className="flex items-start space-x-3 fade-in-up" style={{animationDelay: `${index * 0.1}s`}}>
                    <div className="p-1 bg-primary/20 rounded-full mt-0.5 shrink-0">
                      <CheckCircle className="h-4 w-4 text-primary" />
                    </div>
                    <span className="text-muted-foreground leading-relaxed">{item}</span>
                  </div>
                ))}
              </div>
            </div>

            {/* Traditional Disadvantages */}
            <div className="dark-glass rounded-2xl p-6 lg:p-8 border border-red-500/50 relative overflow-hidden slide-in-right">
              <div className="absolute top-0 right-0 w-32 h-32 bg-gradient-to-bl from-red-500/20 to-transparent rounded-full -translate-y-16 translate-x-16"></div>
              
              <div className="text-center mb-6 relative z-10">
                <div className="w-16 h-16 mx-auto mb-4 rounded-full bg-gradient-to-br from-red-500/20 to-red-500/10 flex items-center justify-center">
                  <XCircle className="h-8 w-8 text-red-400" />
                </div>
                <div className="text-2xl font-bold text-red-400 mb-2">Традиционна реклама</div>
                <div className="text-muted-foreground">Статични билбордове</div>
              </div>
              <div className="space-y-4 relative z-10">
                {comparisonData.others.map((item, index) => (
                  <div key={index} className="flex items-start space-x-3 fade-in-up" style={{animationDelay: `${index * 0.1}s`}}>
                    <div className="p-1 bg-red-500/20 rounded-full mt-0.5 shrink-0">
                      <XCircle className="h-4 w-4 text-red-400" />
                    </div>
                    <span className="text-muted-foreground leading-relaxed">{item}</span>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}