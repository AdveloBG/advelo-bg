import { useState } from "react";
import { Button } from "./ui/button";
import logo from "figma:asset/e377968ce0781b86336a0c308f03923e761eabb3.png";
import { 
  Mail, 
  Phone, 
  MapPin, 
  Facebook, 
  Instagram, 
  Linkedin,
  ArrowUp,
  Send,
  ExternalLink
} from "lucide-react";
import { toast } from "sonner@2.0.3";

export function Footer() {
  const [email, setEmail] = useState('');
  const [isSubscribing, setIsSubscribing] = useState(false);

  const scrollToTop = () => {
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const scrollToSection = (sectionId: string) => {
    const element = document.getElementById(sectionId);
    if (element) {
      element.scrollIntoView({ behavior: 'smooth' });
    }
  };

  const scrollToContactForm = () => {
    // First try to find the contact form specifically
    const contactForm = document.querySelector('#contact form');
    if (contactForm) {
      contactForm.scrollIntoView({ behavior: 'smooth', block: 'center' });
      return;
    }
    
    // Fallback to contact section
    const contactSection = document.getElementById('contact');
    if (contactSection) {
      // Scroll to a bit lower in the contact section to show the form
      const sectionRect = contactSection.getBoundingClientRect();
      const targetY = window.scrollY + sectionRect.top + (sectionRect.height * 0.3);
      window.scrollTo({ top: targetY, behavior: 'smooth' });
    }
  };

  const handleNewsletterSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!email.trim()) return;

    setIsSubscribing(true);
    
    // Simulate newsletter subscription
    setTimeout(() => {
      setIsSubscribing(false);
      toast.success("Благодарим ви! Успешно се абонирахте за нашия бюлетин.");
      setEmail('');
    }, 1500);
  };

  const socialLinks = {
    facebook: "https://facebook.com/advelo.bg",
    instagram: "https://instagram.com/advelo.bg",
    linkedin: "https://linkedin.com/company/advelo-bg"
  };

  return (
    <footer className="bg-gradient-to-t from-dark-gray to-background border-t border-primary/20 relative">
      {/* Subtle background effects */}
      <div className="absolute inset-0 section-pattern-2 opacity-30"></div>
      
      <div className="container-responsive relative z-10">
        
        {/* Main Footer Content */}
        <div className="py-12 lg:py-16">
          
          {/* Top Section - Company Info Centered */}
          <div className="text-center mb-12 lg:mb-16 fade-in-up">
            <div className="flex items-center justify-center mb-6">
              <div className="w-12 lg:w-20 h-px bg-gradient-to-r from-transparent via-primary to-transparent"></div>
              <div className="px-4 lg:px-8">
                <img 
                  src={logo} 
                  alt="Advelo Logo" 
                  className="h-8 sm:h-10 lg:h-12 w-auto object-contain"
                />
              </div>
              <div className="w-12 lg:w-20 h-px bg-gradient-to-r from-primary via-primary to-transparent"></div>
            </div>
            
            <p className="text-muted-foreground max-w-2xl mx-auto mb-8 leading-relaxed">
              Революционизираме външната реклама с мобилни LED дисплеи. 
              Достигнете вашата аудитория където и да е, когато и да е там.
            </p>
            
            {/* Social Media Icons - Centered */}
            <div className="flex justify-center space-x-4">
              <a 
                href={socialLinks.facebook}
                target="_blank"
                rel="noopener noreferrer"
                className="inline-flex items-center justify-center h-10 w-10 text-muted-foreground hover:text-primary hover:bg-primary/10 transition-all duration-300 border border-transparent hover:border-primary/30 rounded-md"
                aria-label="Последвайте ни във Facebook"
                title="Facebook"
              >
                <Facebook className="h-5 w-5" />
              </a>
              <a 
                href={socialLinks.instagram}
                target="_blank"
                rel="noopener noreferrer"
                className="inline-flex items-center justify-center h-10 w-10 text-muted-foreground hover:text-primary hover:bg-primary/10 transition-all duration-300 border border-transparent hover:border-primary/30 rounded-md"
                aria-label="Последвайте ни в Instagram"
                title="Instagram"
              >
                <Instagram className="h-5 w-5" />
              </a>
              <a 
                href={socialLinks.linkedin}
                target="_blank"
                rel="noopener noreferrer"
                className="inline-flex items-center justify-center h-10 w-10 text-muted-foreground hover:text-primary hover:bg-primary/10 transition-all duration-300 border border-transparent hover:border-primary/30 rounded-md"
                aria-label="Последвайте ни в LinkedIn"
                title="LinkedIn"
              >
                <Linkedin className="h-5 w-5" />
              </a>
            </div>
          </div>

          {/* Middle Section - Perfect 3 Column Layout with IDENTICAL Typography */}
          <div className="grid md:grid-cols-3 gap-8 lg:gap-12 mb-12">
            
            {/* Quick Links - Left Column */}
            <div className="text-center slide-in-left">
              <h3 className="text-lg font-semibold text-foreground mb-6 flex items-center justify-center">
                <div className="w-1 h-6 bg-primary rounded-full mr-3"></div>
                Бързи връзки
              </h3>
              <div className="space-y-4">
                <button 
                  onClick={() => scrollToSection('features')}
                  className="block text-muted-foreground hover:text-primary transition-all duration-300 text-center w-full group"
                >
                  <div className="flex items-center justify-center">
                    <div className="w-2 h-2 bg-transparent group-hover:bg-primary rounded-full mr-3 transition-colors"></div>
                    Предимства
                  </div>
                </button>
                <button 
                  onClick={() => scrollToSection('statistics')}
                  className="block text-muted-foreground hover:text-primary transition-all duration-300 text-center w-full group"
                >
                  <div className="flex items-center justify-center">
                    <div className="w-2 h-2 bg-transparent group-hover:bg-primary rounded-full mr-3 transition-colors"></div>
                    Статистики
                  </div>
                </button>
                <button 
                  onClick={() => scrollToSection('how-it-works')}
                  className="block text-muted-foreground hover:text-primary transition-all duration-300 text-center w-full group"
                >
                  <div className="flex items-center justify-center">
                    <div className="w-2 h-2 bg-transparent group-hover:bg-primary rounded-full mr-3 transition-colors"></div>
                    Как работи
                  </div>
                </button>
                <button 
                  onClick={() => scrollToSection('contact')}
                  className="block text-muted-foreground hover:text-primary transition-all duration-300 text-center w-full group"
                >
                  <div className="flex items-center justify-center">
                    <div className="w-2 h-2 bg-transparent group-hover:bg-primary rounded-full mr-3 transition-colors"></div>
                    Получете оферта
                  </div>
                </button>
              </div>
            </div>

            {/* Services - Center Column */}
            <div className="text-center fade-in-up">
              <h3 className="text-lg font-semibold text-foreground mb-6 flex items-center justify-center">
                <div className="w-1 h-6 bg-primary rounded-full mr-3"></div>
                Услуги
              </h3>
              <div className="space-y-4">
                <div className="text-muted-foreground flex items-center justify-center">
                  <div className="w-2 h-2 bg-primary/50 rounded-full mr-3"></div>
                  Локални кампании
                </div>
                <div className="text-muted-foreground flex items-center justify-center">
                  <div className="w-2 h-2 bg-primary/50 rounded-full mr-3"></div>
                  Маркетинг на събития
                </div>
                <div className="text-muted-foreground flex items-center justify-center">
                  <div className="w-2 h-2 bg-primary/50 rounded-full mr-3"></div>
                  Разпознаваемост на бранда
                </div>
                <div className="text-muted-foreground flex items-center justify-center">
                  <div className="w-2 h-2 bg-primary/50 rounded-full mr-3"></div>
                  Планиране на маршрути
                </div>
              </div>
            </div>

            {/* Contact Info - Right Column */}
            <div className="text-center slide-in-right">
              <h3 className="text-lg font-semibold text-foreground mb-6 flex items-center justify-center">
                <div className="w-1 h-6 bg-primary rounded-full mr-3"></div>
                Контакти
              </h3>
              
              {/* Contact Details - Clean centered design */}
              <div className="space-y-4">
                <div className="dark-glass-strong rounded-lg p-4 border border-border hover:border-primary/30 transition-colors">
                  <a 
                    href="mailto:contact@advelo.bg"
                    className="footer-contact-link flex items-center justify-center space-x-3 group transition-all duration-300 hover:scale-105"
                    aria-label="Изпрати имейл до contact@advelo.bg"
                    title="Изпрати имейл до contact@advelo.bg"
                  >
                    <div className="p-2 bg-primary/20 rounded-lg group-hover:bg-primary/30 transition-colors">
                      <Mail className="h-4 w-4 text-primary" />
                    </div>
                    <span className="text-foreground group-hover:text-primary transition-colors">contact@advelo.bg</span>
                  </a>
                </div>
                <div className="dark-glass-strong rounded-lg p-4 border border-border hover:border-primary/30 transition-colors">
                  <a 
                    href="tel:+359889792777"
                    className="footer-contact-link flex items-center justify-center space-x-3 group transition-all duration-300 hover:scale-105"
                    aria-label="Обади се на +359 88 979 2777"
                    title="Обади се на +359 88 979 2777"
                  >
                    <div className="p-2 bg-primary/20 rounded-lg group-hover:bg-primary/30 transition-colors">
                      <Phone className="h-4 w-4 text-primary" />
                    </div>
                    <span className="text-foreground group-hover:text-primary transition-colors">+359 88 979 2777</span>
                  </a>
                </div>
                <div className="dark-glass-strong rounded-lg p-4 border border-border hover:border-primary/30 transition-colors">
                  <div className="flex items-center justify-center space-x-3">
                    <div className="p-2 bg-primary/20 rounded-lg">
                      <MapPin className="h-4 w-4 text-primary" />
                    </div>
                    <span className="text-foreground">София, България</span>
                  </div>
                </div>
              </div>
            </div>
          </div>

          {/* Newsletter Section - Centered at Bottom */}
          <div className="border-t border-primary/20 pt-8 mb-8">
            <div className="text-center fade-in-up">
              <h4 className="text-lg font-semibold text-foreground mb-4 flex items-center justify-center">
                <div className="w-1 h-5 bg-primary rounded-full mr-3"></div>
                Останете в течение
                <div className="w-1 h-5 bg-primary rounded-full ml-3"></div>
              </h4>
              <p className="text-muted-foreground mb-6 max-w-md mx-auto">
                Получавайте последни новини за мобилната реклама и специални оферти
              </p>
              
              {/* Newsletter Form - Centered and Responsive */}
              <div className="max-w-md mx-auto">
                <form onSubmit={handleNewsletterSubmit} className="flex flex-col sm:flex-row gap-3">
                  <input 
                    type="email" 
                    value={email}
                    onChange={(e) => setEmail(e.target.value)}
                    placeholder="Вашият имейл адрес"
                    className="flex-1 h-12 px-4 bg-input border border-border rounded-lg text-foreground focus:border-primary focus:outline-none hover:border-primary/50 transition-all duration-300"
                    required
                  />
                  <Button 
                    type="submit"
                    disabled={isSubscribing || !email.trim()}
                    className="h-12 bg-primary text-primary-foreground hover:bg-primary/90 px-6 transition-all duration-300 pulse-glow font-semibold disabled:opacity-50 disabled:cursor-not-allowed whitespace-nowrap"
                  >
                    {isSubscribing ? (
                      <>
                        <div className="animate-spin rounded-full h-4 w-4 border-2 border-primary-foreground border-t-transparent mr-2"></div>
                        Абониране...
                      </>
                    ) : (
                      <>
                        <Send className="h-4 w-4 mr-2" />
                        Абонирай се
                      </>
                    )}
                  </Button>
                </form>
              </div>
            </div>
          </div>
        </div>

        {/* Bottom Footer - Perfect Symmetry */}
        <div className="py-6 border-t border-primary/20 flex flex-col md:flex-row justify-between items-center space-y-4 md:space-y-0">
          <div className="text-muted-foreground text-center md:text-left">
            © 2024 ADVELO. Всички права запазени.
          </div>
          
          <div className="flex items-center space-x-6">
            <button className="text-muted-foreground hover:text-primary transition-colors flex items-center">
              Политика за поверителност
              <ExternalLink className="h-3 w-3 ml-1" />
            </button>
            <button className="text-muted-foreground hover:text-primary transition-colors flex items-center">
              Условия за ползване
              <ExternalLink className="h-3 w-3 ml-1" />
            </button>
          </div>
          
          <Button 
            onClick={scrollToTop}
            variant="ghost" 
            size="icon"
            className="text-muted-foreground hover:text-primary hover:bg-primary/10 transition-all duration-300 border border-transparent hover:border-primary/30 rounded-full"
            aria-label="Върни се в началото на страницата"
            title="Върни се в началото"
          >
            <ArrowUp className="h-5 w-5" />
          </Button>
        </div>
      </div>

      {/* Enhanced Floating Action Button */}
      <div className="fixed bottom-6 right-6 z-40">
        <Button 
          onClick={scrollToContactForm}
          className="bg-primary text-primary-foreground hover:bg-primary/90 rounded-full w-14 h-14 shadow-2xl transition-all duration-300 pulse-glow"
          aria-label="Отиди към формата за контакти"
          title="Свържи се с нас"
        >
          <Mail className="h-6 w-6" />
        </Button>
      </div>
    </footer>
  );
}