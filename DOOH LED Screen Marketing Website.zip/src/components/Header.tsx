import { useState } from "react";
import { Button } from "./ui/button";
import { Menu, X } from "lucide-react";
import { ThemeToggle } from "./ThemeToggle";
import { useTheme } from "./ThemeProvider";
import adveloLogo from "figma:asset/e377968ce0781b86336a0c308f03923e761eabb3.png";
import adveloLogoLight from "figma:asset/473255efd3132647e7de3da99b12aad71a28cb72.png";

export function Header() {
  const [isMenuOpen, setIsMenuOpen] = useState(false);
  const { theme } = useTheme();

  const toggleMenu = () => {
    setIsMenuOpen(!isMenuOpen);
  };

  const scrollToSection = (sectionId: string) => {
    const element = document.getElementById(sectionId);
    if (element) {
      element.scrollIntoView({ behavior: 'smooth' });
      setIsMenuOpen(false); // Close mobile menu after navigation
    }
  };

  const navItems = [
    { label: "Начало", id: "hero" },
    { label: "Статистики", id: "statistics" },
    { label: "Ценообразуване", id: "pricing" },
    { label: "Предимства", id: "features" },
    { label: "Контакти", id: "contact" }
  ];

  return (
    <>
      {/* Skip link for screen readers */}
      <a 
        href="#main-content" 
        className="skip-link"
      >
        Към основното съдържание
      </a>
      
      <header className="sticky top-0 z-50 w-full backdrop-blur-md bg-background/80 border-b border-border/50 transition-all duration-300">
      <div className="container-responsive">
        <div className="flex h-16 lg:h-20 items-center justify-between">
          
          {/* Logo */}
          <div className="flex items-center">
            <img 
              src={theme === 'light' ? adveloLogoLight : adveloLogo} 
              alt="Advelo - Мобилна LED реклама" 
              className="h-8 lg:h-10 w-auto"
            />
          </div>

          {/* Desktop Navigation */}
          <nav className="hidden lg:flex items-center space-x-1">
            {navItems.map((item) => (
              <Button
                key={item.id}
                variant="ghost"
                onClick={() => scrollToSection(item.id)}
                className="text-foreground hover:text-primary hover:bg-primary/10 transition-all duration-300 px-4 py-2 rounded-lg"
              >
                {item.label}
              </Button>
            ))}
          </nav>

          {/* Theme Toggle & Mobile Menu */}
          <div className="flex items-center space-x-3">
            <ThemeToggle />
            
            {/* Mobile Menu Button */}
            <Button
              variant="ghost"
              size="icon"
              onClick={toggleMenu}
              className="lg:hidden w-10 h-10 rounded-lg bg-background/80 backdrop-blur-md border border-border/50 hover:border-primary/50 transition-all duration-300"
              aria-label="Toggle menu"
            >
              {isMenuOpen ? (
                <X className="h-5 w-5" />
              ) : (
                <Menu className="h-5 w-5" />
              )}
            </Button>
          </div>
        </div>

        {/* Mobile Navigation */}
        {isMenuOpen && (
          <div className="lg:hidden absolute top-full left-0 right-0 bg-background/95 backdrop-blur-md border-b border-border/50 shadow-xl">
            <nav className="container-responsive py-4">
              <div className="flex flex-col space-y-2">
                {navItems.map((item) => (
                  <Button
                    key={item.id}
                    variant="ghost"
                    onClick={() => scrollToSection(item.id)}
                    className="text-foreground hover:text-primary hover:bg-primary/10 justify-start px-4 py-3 rounded-lg transition-all duration-300"
                  >
                    {item.label}
                  </Button>
                ))}
              </div>
            </nav>
          </div>
        )}
      </div>
    </header>
    </>
  );
}