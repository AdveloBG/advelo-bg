import { Button } from "./ui/button";
import { Play, ArrowRight, MapPin, TrendingUp, Clock, Zap, Eye, Target, BarChart3, Users, Monitor } from "lucide-react";
import taxiImage from "figma:asset/5dd7775e93660f8dd3441d3ed9b16d756578a388.png";
import adveloLogo from "figma:asset/e377968ce0781b86336a0c308f03923e761eabb3.png";

export function HeroSection() {
  const scrollToContact = () => {
    const element = document.getElementById('contact');
    if (element) {
      element.scrollIntoView({ behavior: 'smooth' });
    }
  };

  const scrollToPricing = () => {
    const element = document.getElementById('pricing');
    if (element) {
      element.scrollIntoView({ behavior: 'smooth' });
    }
  };

  return (
    <section id="hero" className="relative min-h-screen flex items-center justify-center overflow-hidden bg-background section-pattern-1">
      
      {/* Enhanced background with more visual elements */}
      <div className="absolute inset-0 overflow-hidden pointer-events-none">
        {/* Floating geometric elements - hidden on mobile for performance */}
        <div className="absolute top-20 left-4 lg:left-10 w-2 lg:w-3 h-2 lg:h-3 bg-primary rounded-full pulse-glow"></div>
        <div className="absolute top-40 right-8 lg:right-20 w-1 lg:w-2 h-1 lg:h-2 bg-primary rounded-full pulse-glow" style={{animationDelay: '1s'}}></div>
        <div className="absolute bottom-32 left-8 lg:left-20 w-3 lg:w-4 h-3 lg:h-4 border border-primary rounded-full pulse-glow" style={{animationDelay: '2s'}}></div>
        <div className="absolute bottom-20 right-4 lg:right-10 w-2 lg:w-3 h-2 lg:h-3 bg-primary rounded-full pulse-glow" style={{animationDelay: '0.5s'}}></div>
        <div className="absolute top-60 left-1/2 w-1 lg:w-2 h-1 lg:h-2 bg-primary rounded-full pulse-glow" style={{animationDelay: '1.5s'}}></div>
        
        {/* Enhanced floating icons positioned better - hidden on mobile/tablet */}
        <div className="absolute top-24 right-24 float-animation hidden xl:block">
          <div className="p-3 lg:p-4 dark-glass rounded-xl border border-primary/30 shadow-lg shadow-primary/10">
            <Zap className="h-6 lg:h-8 w-6 lg:w-8 text-primary" />
          </div>
        </div>
        <div className="absolute bottom-32 left-24 float-animation hidden xl:block" style={{animationDelay: '2s'}}>
          <div className="p-3 lg:p-4 dark-glass rounded-xl border border-primary/30 shadow-lg shadow-primary/10">
            <Target className="h-6 lg:h-8 w-6 lg:w-8 text-primary" />
          </div>
        </div>
        <div className="absolute top-1/2 left-12 float-animation hidden 2xl:block" style={{animationDelay: '3s'}}>
          <div className="p-2 lg:p-3 dark-glass rounded-lg border border-primary/30">
            <BarChart3 className="h-5 lg:h-6 w-5 lg:w-6 text-primary" />
          </div>
        </div>
        <div className="absolute top-1/3 right-12 float-animation hidden 2xl:block" style={{animationDelay: '1.8s'}}>
          <div className="p-2 lg:p-3 dark-glass rounded-lg border border-primary/30">
            <Monitor className="h-5 lg:h-6 w-5 lg:w-6 text-primary" />
          </div>
        </div>
        
        {/* LED light trails - simplified on mobile */}
        <div className="absolute top-1/4 left-0 w-full h-px bg-gradient-to-r from-transparent via-primary/30 to-transparent"></div>
        <div className="absolute bottom-1/4 left-0 w-full h-px bg-gradient-to-r from-transparent via-primary/20 to-transparent" style={{animationDelay: '2s'}}></div>
      </div>

      <div className="container-responsive pt-16 lg:pt-20 pb-8 lg:pb-10">
        <div className="grid lg:grid-cols-2 gap-8 lg:gap-16 items-center">
          
          {/* Enhanced content section - better mobile layout */}
          <div className="text-center lg:text-left space-y-6 lg:space-y-8 xl:space-y-10 slide-in-left relative order-2 lg:order-1">
            
            {/* Background accent elements - hidden on mobile */}
            <div className="absolute -top-8 -left-8 w-24 lg:w-32 h-24 lg:h-32 bg-gradient-to-br from-primary/10 to-transparent rounded-full blur-xl hidden lg:block"></div>
            <div className="absolute -bottom-8 -right-8 w-16 lg:w-24 h-16 lg:h-24 bg-gradient-to-tl from-primary/8 to-transparent rounded-full blur-lg hidden lg:block"></div>
            
            <div className="space-y-4 lg:space-y-6 relative z-10">
              <h1 className="text-3xl sm:text-4xl md:text-5xl lg:text-6xl xl:text-7xl font-bold text-foreground leading-tight relative">
                <span className="block text-primary led-flicker relative">
                  Бъдещето на рекламата
                  <div className="absolute -right-2 lg:-right-4 top-1 lg:top-2 w-1 lg:w-2 h-1 lg:h-2 bg-primary rounded-full pulse-glow hidden lg:block"></div>
                </span>
                <span className="block text-muted-foreground mt-2">
                  е тук
                </span>
              </h1>
              
              <p className="text-base sm:text-lg lg:text-xl xl:text-2xl text-muted-foreground max-w-2xl font-medium leading-relaxed">
                Първата и единствена мобилна LED реклама технология в България.
              </p>
              
              <div className="text-sm sm:text-base lg:text-lg xl:text-xl text-foreground max-w-2xl leading-relaxed bg-gradient-to-r from-primary/10 to-transparent p-3 lg:p-4 rounded-lg border border-primary/20">
                <span className="text-primary font-semibold">Постигнете над 6,000,000 импресии месечно</span> с 
                нашите интелигентни LED дисплеи на най-оживените локации в София.
              </div>
            </div>

            {/* Enhanced CTA buttons with better mobile spacing */}
            <div className="flex flex-col sm:flex-row gap-3 lg:gap-4 xl:gap-6 justify-center lg:justify-start relative z-10">
              <Button 
                onClick={scrollToContact}
                className="bg-primary text-primary-foreground hover:bg-primary/90 px-6 lg:px-8 py-4 lg:py-6 text-base lg:text-lg font-semibold group relative overflow-hidden pulse-glow shadow-lg shadow-primary/25 w-full sm:w-auto"
              >
                <span className="relative z-10">Започнете кампания</span>
                <ArrowRight className="ml-2 h-4 lg:h-5 w-4 lg:w-5 group-hover:translate-x-1 transition-transform relative z-10" />
                <div className="absolute inset-0 bg-gradient-to-r from-transparent via-white/20 to-transparent -skew-x-12 translate-x-[-200%] group-hover:translate-x-[200%] transition-transform duration-700"></div>
              </Button>
              
              <Button 
                onClick={scrollToPricing}
                variant="outline" 
                className="border-primary text-primary hover:bg-primary hover:text-primary-foreground px-6 lg:px-8 py-4 lg:py-6 text-base lg:text-lg font-semibold relative overflow-hidden group shadow-lg shadow-primary/10 w-full sm:w-auto"
              >
                <Play className="mr-2 h-4 lg:h-5 w-4 lg:w-5 relative z-10" />
                <span className="relative z-10">Открийте повече</span>
                <div className="absolute inset-0 bg-primary translate-y-full group-hover:translate-y-0 transition-transform duration-300"></div>
              </Button>
            </div>

            {/* Enhanced key stats with better mobile layout */}
            <div className="grid grid-cols-3 gap-3 lg:gap-6 xl:gap-8 pt-6 lg:pt-8 border-t border-border relative z-10">
              <div className="text-center fade-in-up group">
                <div className="flex items-center justify-center mb-3 lg:mb-4">
                  <div className="p-2 lg:p-3 icon-background-1 rounded-lg lg:rounded-xl border border-primary/20 group-hover:scale-110 transition-transform">
                    <MapPin className="h-4 lg:h-6 w-4 lg:w-6 text-primary" />
                  </div>
                </div>
                <div className="text-lg sm:text-xl lg:text-2xl xl:text-3xl text-primary font-bold mb-1 lg:mb-2 group-hover:scale-105 transition-transform">120+</div>
                <div className="text-xs lg:text-sm text-muted-foreground font-medium leading-tight">локации дневно</div>
              </div>
              <div className="text-center fade-in-up group" style={{animationDelay: '0.2s'}}>
                <div className="flex items-center justify-center mb-3 lg:mb-4">
                  <div className="p-2 lg:p-3 icon-background-2 rounded-lg lg:rounded-xl border border-primary/20 group-hover:scale-110 transition-transform">
                    <TrendingUp className="h-4 lg:h-6 w-4 lg:w-6 text-primary" />
                  </div>
                </div>
                <div className="text-lg sm:text-xl lg:text-2xl xl:text-3xl text-primary font-bold mb-1 lg:mb-2 group-hover:scale-105 transition-transform">47%</div>
                <div className="text-xs lg:text-sm text-muted-foreground font-medium leading-tight">по-евтино от билборд</div>
              </div>
              <div className="text-center fade-in-up group" style={{animationDelay: '0.4s'}}>
                <div className="flex items-center justify-center mb-3 lg:mb-4">
                  <div className="p-2 lg:p-3 icon-background-3 rounded-lg lg:rounded-xl border border-primary/20 group-hover:scale-110 transition-transform">
                    <Clock className="h-4 lg:h-6 w-4 lg:w-6 text-primary" />
                  </div>
                </div>
                <div className="text-lg sm:text-xl lg:text-2xl xl:text-3xl text-primary font-bold mb-1 lg:mb-2 group-hover:scale-105 transition-transform">24/7</div>
                <div className="text-xs lg:text-sm text-muted-foreground font-medium leading-tight">активност</div>
              </div>
            </div>
          </div>

          {/* Enhanced taxi image section with better mobile layout */}
          <div className="relative lg:pl-8 slide-in-right order-1 lg:order-2">
            <div className="relative mx-auto max-w-sm lg:max-w-lg">
              
              {/* Main display card with enhanced mobile design */}
              <div className="relative dark-glass rounded-xl lg:rounded-2xl p-4 lg:p-6 xl:p-8 tech-pattern border border-primary/30 shadow-2xl shadow-primary/10">
                <div className="rounded-lg lg:rounded-xl overflow-hidden mb-4 lg:mb-6 relative">
                  <img 
                    src={taxiImage} 
                    alt="Yellow такси с LED екран на ADVELO в центъра на София" 
                    className="w-full h-48 sm:h-56 lg:h-64 xl:h-72 object-cover"
                  />
                  <div className="absolute top-3 lg:top-4 right-3 lg:right-4">
                    <div className="flex items-center space-x-2 bg-black/90 dark:bg-black/80 light:bg-white/95 rounded-md lg:rounded-lg px-2 lg:px-3 py-1 lg:py-2 border border-red-500/50 light:border-red-600/70">
                      <div className="w-1.5 lg:w-2 h-1.5 lg:h-2 bg-red-500 light:bg-red-600 rounded-full led-flicker"></div>
                      <span className="text-white light:text-black text-xs lg:text-sm font-medium">НА ЖИВО</span>
                    </div>
                  </div>
                  <div className="absolute bottom-3 lg:bottom-4 left-3 lg:left-4">
                    <img 
                      src={adveloLogo} 
                      alt="Advelo" 
                      className="h-6 lg:h-8 w-auto opacity-90"
                    />
                  </div>
                  {/* Overlay gradient for better text readability */}
                  <div className="absolute inset-0 bg-gradient-to-t from-black/20 via-transparent to-transparent"></div>
                </div>
                
                <div className="text-center space-y-3 lg:space-y-4">
                  <div className="flex items-center justify-center space-x-2 lg:space-x-3">
                    <div className="p-1.5 lg:p-2 bg-yellow-500 rounded-md lg:rounded-lg shadow-lg">
                      <span className="text-black text-xs lg:text-sm font-bold">ТАКСИ</span>
                    </div>
                    <span className="text-primary font-bold text-sm lg:text-lg">Такси + LED Екран</span>
                  </div>
                  <div className="flex items-center justify-center space-x-3 lg:space-x-4 text-muted-foreground text-xs lg:text-sm">
                    <div className="flex items-center space-x-1 lg:space-x-2">
                      <MapPin className="h-3 lg:h-4 w-3 lg:w-4 text-primary" />
                      <span>Център на София</span>
                    </div>
                    <div className="w-0.5 lg:w-1 h-0.5 lg:h-1 bg-primary rounded-full pulse-glow"></div>
                    <span>Активен сега</span>
                  </div>
                </div>
                
                {/* Enhanced stats overlay with better mobile layout */}
                <div className="mt-4 lg:mt-6 grid grid-cols-2 gap-3 lg:gap-4">
                  <div className="bg-gradient-to-r from-muted/50 to-secondary/50 rounded-md lg:rounded-lg p-3 lg:p-4 text-center border border-border hover:border-primary/50 transition-colors group">
                    <div className="text-primary font-bold text-base lg:text-lg xl:text-xl group-hover:scale-105 transition-transform">6.2M+</div>
                    <div className="text-xs text-muted-foreground font-medium">импресии/месец</div>
                  </div>
                  <div className="bg-gradient-to-r from-muted/50 to-secondary/50 rounded-md lg:rounded-lg p-3 lg:p-4 text-center border border-border hover:border-primary/50 transition-colors group">
                    <div className="flex items-center justify-center mb-1">
                      <div className="w-1.5 lg:w-2 h-1.5 lg:h-2 bg-primary rounded-full mr-1 lg:mr-2 pulse-glow"></div>
                      <span className="text-primary font-bold text-base lg:text-lg xl:text-xl group-hover:scale-105 transition-transform">GPS</span>
                    </div>
                    <div className="text-xs text-muted-foreground font-medium">проследяване</div>
                  </div>
                </div>
              </div>

              {/* Floating stats cards - hidden on mobile and tablet for better performance */}
              <div className="absolute -right-6 lg:-right-8 top-16 lg:top-20 dark-glass rounded-md lg:rounded-lg p-3 lg:p-4 text-center card-hover hidden xl:block border border-primary/30 z-10">
                <div className="flex items-center justify-center mb-2 lg:mb-3">
                  <div className="p-1.5 lg:p-2 bg-primary/20 rounded-md lg:rounded-lg">
                    <Eye className="h-4 lg:h-5 w-4 lg:w-5 text-primary" />
                  </div>
                </div>
                <div className="text-base lg:text-lg font-bold text-primary">92%</div>
                <div className="text-xs text-muted-foreground">повече внимание</div>
              </div>

              <div className="absolute -left-6 lg:-left-8 bottom-12 lg:bottom-16 dark-glass rounded-md lg:rounded-lg p-3 lg:p-4 text-center card-hover hidden xl:block border border-primary/30 z-10">
                <div className="flex items-center justify-center mb-2 lg:mb-3">
                  <div className="p-1.5 lg:p-2 bg-primary/20 rounded-md lg:rounded-lg">
                    <TrendingUp className="h-4 lg:h-5 w-4 lg:w-5 text-primary" />
                  </div>
                </div>
                <div className="text-base lg:text-lg font-bold text-primary">3x</div>
                <div className="text-xs text-muted-foreground">по-запомняща</div>
              </div>
              
              {/* Additional floating element - hidden on mobile/tablet */}
              <div className="absolute top-1/2 -right-8 lg:-right-12 dark-glass rounded-md lg:rounded-lg p-2 lg:p-3 hidden 2xl:block border border-primary/30 card-hover">
                <div className="text-center">
                  <div className="flex items-center justify-center mb-1 lg:mb-2">
                    <div className="p-1 bg-primary/20 rounded">
                      <Users className="h-3 lg:h-4 w-3 lg:w-4 text-primary" />
                    </div>
                  </div>
                  <div className="text-sm font-bold text-primary">5x</div>
                  <div className="text-xs text-muted-foreground">гледания</div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}