import { Card, CardContent } from "./ui/card";
import { Button } from "./ui/button";
import { ArrowRight, CheckCircle, Settings, Workflow } from "lucide-react";
import { processSteps, platformBenefits, campaignTypes } from "./data/processData";

export function HowItWorksSection() {
  const scrollToContact = () => {
    const element = document.getElementById('contact');
    if (element) {
      element.scrollIntoView({ behavior: 'smooth' });
    }
  };

  return (
    <section id="how-it-works" className="py-12 lg:py-16 bg-gradient-to-b from-background to-dark-gray tech-pattern relative">
      <div className="container-responsive">
        
        {/* Compact header */}
        <div className="text-center mb-8 lg:mb-12 fade-in-up">
          <div className="flex items-center justify-center mb-4">
            <div className="w-16 h-px bg-gradient-to-r from-transparent via-primary to-transparent"></div>
            <div className="px-6">
              <div className="p-3 dark-glass rounded-full border border-primary/30">
                <Workflow className="h-6 w-6 text-primary" />
              </div>
            </div>
            <div className="w-16 h-px bg-gradient-to-r from-primary via-primary to-transparent"></div>
          </div>
          
          <h2 className="text-2xl md:text-3xl lg:text-4xl text-foreground mb-4 font-bold">
            Как <span className="text-primary">работи</span>
          </h2>
          <p className="text-base lg:text-lg text-muted-foreground max-w-2xl mx-auto leading-relaxed">
            Само 3 стъпки до стартиране на вашата мобилна LED кампания
          </p>
        </div>

        {/* Compact process steps */}
        <div className="grid md:grid-cols-3 gap-6 lg:gap-8 mb-12 lg:mb-16">
          {processSteps.slice(0, 3).map((step, index) => (
            <Card key={index} className="dark-glass border-border hover:border-primary/50 transition-all duration-300 card-hover relative overflow-hidden fade-in-up" style={{animationDelay: `${index * 0.1}s`}}>
              <div className="absolute top-0 right-0 w-20 h-20 bg-gradient-to-bl from-primary/15 to-transparent rounded-full -translate-y-10 translate-x-10"></div>
              
              <CardContent className="p-6 text-center relative z-10">
                {/* Step number */}
                <div className="relative mb-4">
                  <div className="w-12 h-12 mx-auto bg-gradient-to-br from-primary to-primary/80 rounded-full flex items-center justify-center text-primary-foreground font-bold text-lg shadow-lg shadow-primary/25">
                    {step.number}
                  </div>
                  <div className="absolute inset-0 bg-primary rounded-full pulse-glow opacity-30 mx-auto w-12 h-12"></div>
                </div>


                
                <h3 className="text-lg lg:text-xl text-foreground mb-3 font-semibold">{step.title}</h3>
                <p className="text-muted-foreground text-sm lg:text-base leading-relaxed mb-4">{step.description}</p>
                
                {/* Only show first 2 details */}
                <div className="space-y-2">
                  {step.details.slice(0, 2).map((detail, detailIndex) => (
                    <div key={detailIndex} className="flex items-start text-xs lg:text-sm text-muted-foreground">
                      <div className="p-0.5 bg-primary/20 rounded-full mr-2 mt-1 shrink-0">
                        <CheckCircle className="h-3 w-3 text-primary" />
                      </div>
                      <span className="leading-relaxed">{detail}</span>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          ))}
        </div>

        {/* Compact CTA section */}
        <div className="dark-glass-strong rounded-xl p-6 lg:p-8 border border-primary/30 text-center relative overflow-hidden">
          <div className="absolute top-0 left-0 w-32 h-32 bg-gradient-to-br from-primary/10 to-transparent rounded-full -translate-y-16 -translate-x-16"></div>
          
          <div className="relative z-10">
            <h3 className="text-xl md:text-2xl lg:text-3xl text-foreground font-bold mb-4">
              Готови за <span className="text-primary">стартиране</span>?
            </h3>
            <p className="text-muted-foreground mb-6 max-w-2xl mx-auto">
              Свържете се с нас за безплатна консултация и персонализирана оферта
            </p>
            
            <Button 
              onClick={scrollToContact}
              className="bg-primary text-primary-foreground hover:bg-primary/90 px-8 py-4 text-lg font-semibold relative overflow-hidden group pulse-glow"
            >
              <span className="relative z-10">Започнете кампанията си</span>
              <ArrowRight className="ml-2 h-5 w-5 relative z-10 group-hover:translate-x-1 transition-transform" />
              <div className="absolute inset-0 bg-gradient-to-r from-transparent via-white/20 to-transparent -skew-x-12 translate-x-[-200%] group-hover:translate-x-[200%] transition-transform duration-700"></div>
            </Button>
          </div>
        </div>
      </div>
    </section>
  );
}