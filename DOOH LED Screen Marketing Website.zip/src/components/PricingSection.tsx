import { Badge } from "./ui/badge";
import { TrendingUp, CheckCircle, X, Eye, Clock, Award, Zap, Users } from "lucide-react";
import { ThemeAwareLogo } from "./ThemeAwareLogo";

export function PricingSection() {
  const comparisonData = [
    {
      metric: "Цена за 1000 показвания (CPM)",
      traditional: "25.00 лв",
      advelo: "13.25 лв",
      savings: "47% по-евтино",
      icon: TrendingUp
    },
    {
      metric: "Дневни експозиции", 
      traditional: "1 локация",
      advelo: "5+ локации",
      savings: "5x повече гледания",
      icon: Eye
    },
    {
      metric: "Визуално задържане",
      traditional: "2.1 секунди",
      advelo: "4.8 секунди", 
      savings: "2.3x по-дълго",
      icon: Clock
    },
    {
      metric: "Brand Recall",
      traditional: "23%",
      advelo: "69%",
      savings: "3x по-запомнящо",
      icon: Award
    },
    {
      metric: "Гъвкавост на кампанията",
      traditional: "Статично съдържание",
      advelo: "Динамично съдържание",
      savings: "Неограничени промени",
      icon: Zap
    },
    {
      metric: "Проследяване в реално време",
      traditional: "Няма данни",
      advelo: "GPS + аналитика",
      savings: "100% прозрачност",
      icon: Users
    }
  ];

  return (
    <section id="pricing" className="py-16 lg:py-20 bg-gradient-to-b from-dark-gray to-background relative overflow-hidden section-pattern-1">
      {/* Background effects */}
      <div className="absolute top-0 left-0 w-full h-px bg-gradient-to-r from-transparent via-primary/50 to-transparent"></div>
      <div className="absolute bottom-0 left-0 w-full h-px bg-gradient-to-r from-transparent via-primary/30 to-transparent"></div>

      <div className="container-responsive relative z-10">
        {/* Pricing Comparison Table */}
        <div className="dark-glass-strong rounded-2xl p-8 lg:p-12 border border-primary/30 relative overflow-hidden">
          <div className="absolute inset-0 bg-gradient-to-br from-primary/5 to-transparent"></div>
          
          <div className="relative z-10">
            <div className="text-center mb-8 lg:mb-12">
              <div className="flex items-center justify-center mb-6">
                <div className="p-4 bg-primary/20 rounded-full border border-primary/40">
                  <TrendingUp className="h-8 w-8 text-primary" />
                </div>
              </div>
              <h2 className="text-2xl md:text-3xl lg:text-4xl text-foreground font-bold mb-4">
                Сравнение на <span className="text-primary">ценообразуването</span>
              </h2>
              <p className="text-muted-foreground max-w-2xl mx-auto leading-relaxed">
                Вижте защо клиентите ни постигат 47% по-добри резултати при значително по-ниска цена
                в сравнение с традиционната външна реклама.
              </p>
            </div>

            {/* Comparison Table */}
            <div className="overflow-x-auto">
              <div className="min-w-full">
                {/* Table Header */}
                <div className="grid grid-cols-4 gap-4 mb-6 p-4 bg-secondary rounded-lg border border-border">
                  <div className="text-foreground font-semibold">Метрика</div>
                  <div className="text-center text-muted-foreground font-medium">Традиционен билборд</div>
                  <div className="text-center text-primary font-semibold flex items-center justify-center">
                    <ThemeAwareLogo 
                      className="h-5 w-auto mr-2"
                      alt="Advelo"
                    />
                    LED
                  </div>
                  <div className="text-center text-foreground font-medium">Предимство</div>
                </div>

                {/* Table Rows */}
                <div className="space-y-4">
                  {comparisonData.map((row, index) => (
                    <div key={index} className="grid grid-cols-4 gap-4 p-4 bg-card rounded-lg border border-border hover:border-primary/50 transition-all duration-300 card-hover fade-in-up" style={{animationDelay: `${index * 0.1}s`}}>
                      
                      {/* Metric */}
                      <div className="flex items-center space-x-3">
                        <div className="p-2 bg-primary/20 rounded-lg">
                          <row.icon className="h-5 w-5 text-primary" />
                        </div>
                        <span className="text-foreground font-medium">{row.metric}</span>
                      </div>

                      {/* Traditional */}
                      <div className="text-center flex items-center justify-center space-x-2">
                        <X className="h-4 w-4 text-red-500" />
                        <span className="text-muted-foreground">{row.traditional}</span>
                      </div>

                      {/* Advelo */}
                      <div className="text-center flex items-center justify-center space-x-2">
                        <CheckCircle className="h-4 w-4 text-primary" />
                        <span className="text-primary font-semibold">{row.advelo}</span>
                      </div>

                      {/* Savings */}
                      <div className="text-center">
                        <span className="bg-primary/10 text-primary px-3 py-1 rounded-full text-sm font-medium">
                          {row.savings}
                        </span>
                      </div>
                    </div>
                  ))}
                </div>

                {/* Summary Footer */}
                <div className="mt-8 p-6 bg-gradient-to-r from-primary/10 to-primary/5 rounded-lg border border-primary/30">
                  <div className="text-center">
                    <div className="text-2xl lg:text-3xl font-bold text-primary mb-2">
                      Общо: 47% по-евтино + 3x по-добри резултати
                    </div>
                    <div className="text-muted-foreground">
                      Платете по-малко, получете повече внимание и по-добро запомняне на марката
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}