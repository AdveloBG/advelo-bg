import { Card, CardContent } from "./ui/card";
import { Badge } from "./ui/badge";
import { Star, MapPin, Users, TrendingUp, Zap, Clock, Eye, Award } from "lucide-react";
import { ImageWithFallback } from './figma/ImageWithFallback';

export function ShowcaseSection() {
  const showcaseItems = [
    {
      title: "Centrum Sofia Mall",
      location: "София, бул. Александър Стамболийски",
      impressions: "125,000",
      engagement: "94%",
      image: "https://images.unsplash.com/photo-1673410831250-99d2be3c4ce5?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxzb2ZpYSUyMGJ1bGdhcmlhJTIwbWFsbCUyMHNob3BwaW5nJTIwY2VudGVyfGVufDF8fHx8MTc1NTYxMjYwNXww&ixlib=rb-4.1.0&q=80&w=1080"
    },
    {
      title: "Business Park Sofia",
      location: "София, бул. Цариградско шосе",
      impressions: "87,500",
      engagement: "91%",
      image: "https://images.unsplash.com/photo-1629546013882-9d9459e26bf3?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxzb2ZpYSUyMGJ1bGdhcmlhJTIwYnVzaW5lc3MlMjBkaXN0cmljdCUyMG9mZmljZSUyMGJ1aWxkaW5nc3xlbnwxfHx8fDE3NTU2MTI1OTh8MA&ixlib=rb-4.1.0&q=80&w=1080"
    },
    {
      title: "Летище София",
      location: "София, Терминал 2",
      impressions: "156,000",
      engagement: "96%",
      image: "https://images.unsplash.com/photo-1601681669147-f7eb15c35e75?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxzb2ZpYSUyMGJ1bGdhcmlhJTIwYWlycG9ydCUyMHRlcm1pbmFsfGVufDF8fHx8MTc1NTYxMjYxMHww&ixlib=rb-4.1.0&q=80&w=1080"
    }
  ];

  const liveStats = [
    { icon: Eye, value: "2.4M+", label: "Импресии тази седмица" },
    { icon: Users, value: "850K+", label: "Уникални зрители" },
    { icon: TrendingUp, value: "94.2%", label: "Средна ангажираност" },
    { icon: MapPin, value: "320+", label: "Активни маршрути" }
  ];



  return (
    <section className="py-16 lg:py-20 bg-gradient-to-b from-dark-gray to-background circuit-pattern relative overflow-hidden">
      {/* Background DOOH image */}
      <div className="absolute inset-0 opacity-5">
        <ImageWithFallback
          src="https://images.unsplash.com/photo-1675700189677-b6f505c214a2?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHNlYXJjaHwxfHxvdXRkb29yJTIwZGlnaXRhbCUyMHNpZ25hZ2UlMjBkaXNwbGF5fGVufDF8fHx8MTc1NTYwNTIwN3ww&ixlib=rb-4.1.0&q=80&w=1080"
          alt="Outdoor Digital Signage"
          className="w-full h-full object-cover"
        />
      </div>

      <div className="container-responsive relative z-10">
        
        {/* Enhanced header with symmetrical design */}
        <div className="text-center mb-12 lg:mb-16 fade-in-up">
          <div className="flex items-center justify-center mb-6">
            <div className="w-16 h-px bg-gradient-to-r from-transparent via-primary to-transparent"></div>
            <div className="px-6">
              <div className="p-3 dark-glass rounded-full border border-primary/30">
                <Award className="h-8 w-8 text-primary" />
              </div>
            </div>
            <div className="w-16 h-px bg-gradient-to-r from-primary via-primary to-transparent"></div>
          </div>
          
          <h2 className="text-3xl md:text-4xl lg:text-5xl text-foreground mb-6 font-bold">
            Нашите кампании
            <span className="text-primary block mt-2">в действие</span>
          </h2>
          <p className="text-muted-foreground max-w-3xl mx-auto leading-relaxed">
            Вижте как водещите български компании постигат невероятни резултати 
            с нашата мобилна LED реклама технология в реални условия.
          </p>
        </div>

        {/* Live statistics dashboard */}
        <div className="grid grid-cols-2 lg:grid-cols-4 gap-4 lg:gap-6 mb-16 lg:mb-20">
          {liveStats.map((stat, index) => (
            <div key={index} className="dark-glass-strong rounded-xl p-6 border border-primary/30 text-center card-hover group fade-in-up" style={{animationDelay: `${index * 0.1}s`}}>
              <div className="flex items-center justify-center mb-4">
                <div className="p-3 bg-primary/20 rounded-lg group-hover:scale-110 transition-transform">
                  <stat.icon className="h-6 w-6 text-primary" />
                </div>
              </div>
              <div className="text-2xl lg:text-3xl font-bold text-primary mb-2 group-hover:scale-105 transition-transform">
                {stat.value}
              </div>
              <div className="text-muted-foreground font-medium leading-tight">
                {stat.label}
              </div>
            </div>
          ))}
        </div>

        {/* Success stories showcase with Sofia images */}
        <div className="grid lg:grid-cols-3 gap-8 lg:gap-12 mb-16 lg:mb-20">
          {showcaseItems.map((item, index) => (
            <Card key={index} className="dark-glass border-primary/30 card-hover group relative overflow-hidden fade-in-up" style={{animationDelay: `${index * 0.2}s`}}>
              <div className="absolute top-0 right-0 w-24 h-24 bg-gradient-to-bl from-primary/15 to-transparent rounded-full -translate-y-12 translate-x-12"></div>
              
              <CardContent className="p-0 relative z-10">
                <div className="relative">
                  <ImageWithFallback
                    src={item.image}
                    alt={item.title}
                    className="w-full h-48 lg:h-56 object-cover rounded-t-lg"
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-background/60 via-transparent to-transparent rounded-t-lg"></div>
                  
                  {/* Live indicator */}
                  <div className="absolute top-4 right-4">
                    <Badge className="bg-primary text-primary-foreground hover:bg-primary font-semibold">
                      <div className="w-2 h-2 bg-primary-foreground rounded-full mr-2 led-flicker"></div>
                      АКТИВНА
                    </Badge>
                  </div>
                  
                  {/* Location */}
                  <div className="absolute bottom-4 left-4">
                    <div className="flex items-center space-x-2 text-foreground">
                      <MapPin className="h-4 w-4" />
                      <span className="text-sm font-medium">{item.location}</span>
                    </div>
                  </div>
                </div>
                
                <div className="p-6">
                  <h3 className="text-xl font-bold text-foreground mb-4 group-hover:text-primary transition-colors">
                    {item.title}
                  </h3>
                  
                  <div className="grid grid-cols-2 gap-4">
                    <div className="text-center p-3 bg-secondary rounded-lg border border-border hover:border-primary/50 transition-colors">
                      <div className="text-primary font-bold text-lg">{item.impressions}</div>
                      <div className="text-muted-foreground">импресии/ден</div>
                    </div>
                    <div className="text-center p-3 bg-secondary rounded-lg border border-border hover:border-primary/50 transition-colors">
                      <div className="text-primary font-bold text-lg">{item.engagement}</div>
                      <div className="text-muted-foreground">ангажираност</div>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>




      </div>
    </section>
  );
}