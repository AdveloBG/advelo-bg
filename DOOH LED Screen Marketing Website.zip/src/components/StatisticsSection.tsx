import { Card, CardContent, CardHeader, CardTitle } from "./ui/card";
import { 
  BarChart, 
  Bar, 
  XAxis, 
  YAxis, 
  CartesianGrid, 
  Tooltip, 
  ResponsiveContainer,
  LineChart,
  Line,
  PieChart,
  Pie,
  Cell,
  AreaChart,
  Area
} from "recharts";
import { 
  impressionData, 
  performanceData, 
  audienceData, 
  locationData, 
  keyMetrics, 
  marketStats,
  dailyStats,
  comparisonStats
} from "./data/statisticsData";
import { TrendingUp, Target, Eye, MapPin, BarChart3, Users, Zap, Clock } from "lucide-react";
import { ImageWithFallback } from './figma/ImageWithFallback';

const chartTooltipStyle = {
  backgroundColor: "#111111", 
  border: "1px solid var(--neon-green)",
  borderRadius: "8px",
  color: "#ffffff"
};

export function StatisticsSection() {
  return (
    <section id="statistics" className="py-16 lg:py-20 bg-gradient-to-b from-background to-secondary/20 section-pattern-2 relative">
      {/* Background DOOH image with overlay */}
      <div className="absolute inset-0 opacity-5">
        <ImageWithFallback
          src="https://images.unsplash.com/photo-1551288049-bebda4e38f71?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxidXNpbmVzcyUyMGFuYWx5dGljcyUyMGRhdGElMjB2aXN1YWxpemF0aW9ufGVufDF8fHx8MTc1NTQ5NDg1OXww&ixlib=rb-4.1.0&q=80&w=1080"
          alt="Business Analytics Background"
          className="w-full h-full object-cover"
        />
      </div>

      <div className="container-responsive relative z-10">
        
        {/* Enhanced symmetrical header */}
        <div className="text-center mb-12 lg:mb-16 fade-in-up">
          <div className="flex items-center justify-center mb-6">
            <div className="w-20 h-px bg-gradient-to-r from-transparent via-primary to-transparent"></div>
            <div className="px-8">
              <div className="p-4 dark-glass rounded-full border border-primary/30">
                <BarChart3 className="h-8 w-8 text-primary" />
              </div>
            </div>
            <div className="w-20 h-px bg-gradient-to-r from-primary via-primary to-transparent"></div>
          </div>
          
          <h2 className="text-3xl md:text-4xl lg:text-5xl text-foreground mb-6 font-bold">
            Защо да изберете
            <span className="text-primary block mt-2 font-bold">ADVELO?</span>
          </h2>
          <p className="text-muted-foreground max-w-3xl mx-auto leading-relaxed">
            Нашата мобилна LED реклама доставя измерими резултати с GPS проследяване 
            в реално време и детайлна аналитика на всяка кампания.
          </p>
        </div>

        {/* Enhanced symmetrical key metrics grid - FIXED static numbers */}
        <div className="grid grid-cols-2 lg:grid-cols-4 gap-4 lg:gap-6 mb-16 lg:mb-20">
          {keyMetrics.map((metric, index) => {
            const icons = [Eye, TrendingUp, MapPin, Clock];
            const Icon = icons[index];
            const gradients = [
              "from-blue-500/10 to-blue-600/5",
              "from-primary/10 to-primary/5", 
              "from-purple-500/10 to-purple-600/5",
              "from-orange-500/10 to-orange-600/5"
            ];
            return (
              <Card key={index} className="dark-glass border-border text-center card-hover group hover:border-primary/50 fade-in-up" style={{animationDelay: `${index * 0.1}s`}}>
                <CardContent className="p-4 lg:p-6">
                  <div className={`w-12 h-12 mx-auto mb-4 rounded-full bg-gradient-to-br ${gradients[index]} flex items-center justify-center group-hover:scale-110 transition-all duration-300`}>
                    <Icon className="h-6 w-6 text-primary" />
                  </div>
                  <div className="text-2xl lg:text-3xl text-primary mb-3 font-bold">
                    {metric.value}
                  </div>
                  <div className="text-xs lg:text-sm text-muted-foreground leading-tight">
                    {metric.label}
                  </div>
                </CardContent>
              </Card>
            );
          })}
        </div>

        {/* Enhanced daily stats with perfect symmetry */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-16 lg:mb-20">
          {dailyStats.map((stat, index) => {
            const icons = [MapPin, Eye, Clock, Target];
            const Icon = icons[index];
            const backgrounds = [
              "bg-gradient-to-br from-blue-500/10 to-blue-600/5",
              "bg-gradient-to-br from-primary/10 to-primary/5",
              "bg-gradient-to-br from-purple-500/10 to-purple-600/5",
              "bg-gradient-to-br from-red-500/10 to-red-600/5"
            ];
            return (
              <div key={index} className={`dark-glass rounded-xl p-6 border border-primary/30 card-hover group ${backgrounds[index]} fade-in-up`} style={{animationDelay: `${index * 0.15}s`}}>
                <div className="text-center">
                  <div className="w-14 h-14 mx-auto mb-4 rounded-full bg-primary/20 flex items-center justify-center group-hover:bg-primary/30 transition-all duration-300 group-hover:scale-110">
                    <Icon className="h-7 w-7 text-primary" />
                  </div>
                  <div className="text-2xl lg:text-3xl font-bold text-primary mb-3 group-hover:scale-105 transition-transform">{stat.value}</div>
                  <div className="text-foreground font-semibold mb-2 text-sm lg:text-base">{stat.metric}</div>
                  <div className="text-xs lg:text-sm text-muted-foreground leading-relaxed">{stat.description}</div>
                </div>
              </div>
            );
          })}
        </div>

        {/* Enhanced charts grid with perfect alignment */}
        <div className="grid lg:grid-cols-2 gap-8 lg:gap-12 mb-16 lg:mb-20">
          
          {/* Daily Impressions Chart */}
          <Card className="dark-glass border-border card-hover relative overflow-hidden slide-in-left">
            <div className="absolute inset-0 opacity-10">
              <ImageWithFallback
                src="https://images.unsplash.com/photo-1533069027836-fa937181a8ce?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxkaWdpdGFsJTIwYmlsbGJvYXJkJTIwY2l0eSUyMG91dGRvb3IlMjBhZHZlcnRpc2luZ3xlbnwxfHx8fDE3NTU2MDUxOTl8MA&ixlib=rb-4.1.0&q=80&w=1080"
                alt="Digital Billboard"
                className="w-full h-full object-cover"
              />
            </div>
            <CardHeader className="relative z-10 pb-4">
              <CardTitle className="text-foreground font-semibold flex items-center justify-center lg:justify-start">
                <div className="p-3 icon-background-1 rounded-lg mr-3">
                  <TrendingUp className="h-6 w-6 text-primary" />
                </div>
                Ежедневни импресии по часове
              </CardTitle>
            </CardHeader>
            <CardContent className="relative z-10">
              <ResponsiveContainer width="100%" height={320}>
                <AreaChart data={impressionData} margin={{ top: 10, right: 30, left: 0, bottom: 0 }}>
                  <defs>
                    <linearGradient id="areaGradient" x1="0" y1="0" x2="0" y2="1">
                      <stop offset="5%" stopColor="var(--primary)" stopOpacity={0.4}/>
                      <stop offset="95%" stopColor="var(--primary)" stopOpacity={0}/>
                    </linearGradient>
                  </defs>
                  <CartesianGrid strokeDasharray="3 3" stroke="var(--border)" />
                  <XAxis dataKey="time" stroke="var(--muted-foreground)" fontSize={12} />
                  <YAxis stroke="var(--muted-foreground)" fontSize={12} />
                  <Tooltip 
                    contentStyle={{
                      backgroundColor: "var(--card)", 
                      border: "1px solid var(--primary)",
                      borderRadius: "8px",
                      color: "var(--card-foreground)"
                    }}
                  />
                  <Area 
                    type="monotone" 
                    dataKey="impressions" 
                    stroke="var(--primary)" 
                    fill="url(#areaGradient)"
                    strokeWidth={3}
                    isAnimationActive={true}
                    animationBegin={200}
                    animationDuration={2000}
                  />
                </AreaChart>
              </ResponsiveContainer>
            </CardContent>
          </Card>

          {/* Performance Comparison Chart */}
          <Card className="dark-glass border-border card-hover relative overflow-hidden slide-in-right">
            <div className="absolute inset-0 opacity-10">
              <ImageWithFallback
                src="https://images.unsplash.com/photo-1652765436113-3f856919ff53?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxMRUQlMjBzY3JlZW4lMjBhZHZlcnRpc2luZyUyMG5pZ2h0JTIwY2l0eXxlbnwxfHx8fDE3NTU2MDUyMDN8MA&ixlib=rb-4.1.0&q=80&w=1080"
                alt="LED Screen Advertising"
                className="w-full h-full object-cover"
              />
            </div>
            <CardHeader className="relative z-10 pb-4">
              <CardTitle className="text-foreground font-semibold flex items-center justify-center lg:justify-start">
                <div className="p-3 icon-background-2 rounded-lg mr-3">
                  <Target className="h-6 w-6 text-primary" />
                </div>
                ADVELO срещу традиционна реклама
              </CardTitle>
            </CardHeader>
            <CardContent className="relative z-10">
              <ResponsiveContainer width="100%" height={320}>
                <BarChart data={performanceData} margin={{ top: 10, right: 30, left: 0, bottom: 0 }}>
                  <CartesianGrid strokeDasharray="3 3" stroke="var(--border)" />
                  <XAxis dataKey="month" stroke="var(--muted-foreground)" fontSize={12} />
                  <YAxis stroke="var(--muted-foreground)" fontSize={12} />
                  <Tooltip 
                    contentStyle={{
                      backgroundColor: "var(--card)", 
                      border: "1px solid var(--primary)",
                      borderRadius: "8px",
                      color: "var(--card-foreground)"
                    }}
                  />
                  <Bar 
                    dataKey="traditional" 
                    fill="var(--chart-3)" 
                    name="Традиционна" 
                    radius={[4, 4, 0, 0]}
                    isAnimationActive={true}
                    animationBegin={400}
                    animationDuration={1500}
                  />
                  <Bar 
                    dataKey="mobileLED" 
                    fill="var(--primary)" 
                    name="ADVELO LED" 
                    radius={[4, 4, 0, 0]}
                    isAnimationActive={true}
                    animationBegin={800}
                    animationDuration={1500}
                  />
                </BarChart>
              </ResponsiveContainer>
            </CardContent>
          </Card>
        </div>

        {/* Second row of charts with enhanced alignment */}
        <div className="grid lg:grid-cols-2 gap-8 lg:gap-12 mb-16 lg:mb-20">
          
          {/* Cost Efficiency by Time */}
          <Card className="dark-glass border-border card-hover slide-in-left">
            <CardHeader className="pb-4">
              <CardTitle className="text-foreground font-semibold flex items-center justify-center lg:justify-start">
                <div className="p-3 icon-background-3 rounded-lg mr-3">
                  <Clock className="h-6 w-6 text-primary" />
                </div>
                Цена за импресия по час от деня
              </CardTitle>
            </CardHeader>
            <CardContent>
              <ResponsiveContainer width="100%" height={320}>
                <AreaChart 
                  data={[
                    { hour: "6ч", cpm: 8.5, impressions: 450 },
                    { hour: "8ч", cpm: 12.2, impressions: 820 },
                    { hour: "10ч", cpm: 15.8, impressions: 1150 },
                    { hour: "12ч", cpm: 18.3, impressions: 1420 },
                    { hour: "14ч", cpm: 16.7, impressions: 1380 },
                    { hour: "16ч", cpm: 19.2, impressions: 1650 },
                    { hour: "18ч", cpm: 22.4, impressions: 1890 },
                    { hour: "20ч", cpm: 17.9, impressions: 1280 },
                    { hour: "22ч", cpm: 11.6, impressions: 720 }
                  ]}
                  margin={{ top: 10, right: 30, left: 0, bottom: 0 }}
                >
                  <defs>
                    <linearGradient id="cpmGradient" x1="0" y1="0" x2="0" y2="1">
                      <stop offset="5%" stopColor="var(--primary)" stopOpacity={0.4}/>
                      <stop offset="95%" stopColor="var(--primary)" stopOpacity={0.1}/>
                    </linearGradient>
                  </defs>
                  <CartesianGrid strokeDasharray="3 3" stroke="var(--border)" />
                  <XAxis dataKey="hour" stroke="var(--muted-foreground)" fontSize={12} />
                  <YAxis stroke="var(--muted-foreground)" fontSize={12} />
                  <Tooltip 
                    contentStyle={{
                      backgroundColor: "var(--card)", 
                      border: "1px solid var(--primary)",
                      borderRadius: "8px",
                      color: "var(--card-foreground)"
                    }}
                    formatter={(value, name) => [
                      name === 'cpm' ? `${value} лв.` : `${value}`,
                      name === 'cpm' ? 'CPM' : 'Импресии'
                    ]}
                  />
                  <Area 
                    type="monotone" 
                    dataKey="cpm" 
                    stroke="var(--primary)" 
                    fill="url(#cpmGradient)"
                    strokeWidth={3}
                    isAnimationActive={true}
                    animationBegin={600}
                    animationDuration={2200}
                  />
                </AreaChart>
              </ResponsiveContainer>
            </CardContent>
          </Card>

          {/* Brand Recognition by Industry */}
          <Card className="dark-glass border-border card-hover relative overflow-hidden slide-in-right">
            <div className="absolute inset-0 opacity-5">
              <ImageWithFallback
                src="https://images.unsplash.com/photo-1751865518405-d0c5d5b3e292?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHx1cmJhbiUyMHN0cmVldCUyMGFkdmVydGlzaW5nJTIwZGlzcGxheXxlbnwxfHx8fDE3NTU2MDUyMTh8MA&ixlib=rb-4.1.0&q=80&w=1080"
                alt="Urban Street Display"
                className="w-full h-full object-cover"
              />
            </div>
            <CardHeader className="relative z-10 pb-4">
              <CardTitle className="text-foreground font-semibold flex items-center justify-center lg:justify-start">
                <div className="p-3 bg-gradient-to-br from-orange-500/20 to-orange-600/5 rounded-lg mr-3">
                  <Target className="h-6 w-6 text-primary" />
                </div>
                Запомняне на марката по индустрия
              </CardTitle>
            </CardHeader>
            <CardContent className="relative z-10">
              <ResponsiveContainer width="100%" height={320}>
                <BarChart 
                  data={[
                    { industry: "Ресторанти", traditional: 18, mobile: 72 },
                    { industry: "Мода", traditional: 23, mobile: 68 },
                    { industry: "Автомобили", traditional: 28, mobile: 75 },
                    { industry: "IT", traditional: 15, mobile: 62 },
                    { industry: "Недвижими", traditional: 21, mobile: 69 },
                    { industry: "Здраве", traditional: 19, mobile: 64 }
                  ]}
                  margin={{ top: 10, right: 30, left: 20, bottom: 30 }}
                >
                  <CartesianGrid strokeDasharray="3 3" stroke="var(--border)" />
                  <XAxis 
                    dataKey="industry" 
                    stroke="var(--muted-foreground)" 
                    fontSize={11}
                    angle={-45}
                    textAnchor="end"
                    height={60}
                  />
                  <YAxis 
                    stroke="var(--muted-foreground)" 
                    fontSize={12}
                    label={{ value: 'Brand Recall (%)', angle: -90, position: 'insideLeft', style: { textAnchor: 'middle', fill: 'var(--muted-foreground)' } }}
                  />
                  <Tooltip 
                    contentStyle={{
                      backgroundColor: "var(--card)", 
                      border: "1px solid var(--primary)",
                      borderRadius: "8px",
                      color: "var(--card-foreground)"
                    }}
                    formatter={(value, name) => [`${value}%`, name === 'traditional' ? 'Статичен билборд' : 'ADVELO LED']}
                  />
                  <Bar 
                    dataKey="traditional" 
                    fill="var(--chart-3)" 
                    name="traditional"
                    radius={[2, 2, 0, 0]}
                    isAnimationActive={true}
                    animationBegin={300}
                    animationDuration={1800}
                  />
                  <Bar 
                    dataKey="mobile" 
                    fill="var(--primary)" 
                    name="mobile"
                    radius={[2, 2, 0, 0]}
                    isAnimationActive={true}
                    animationBegin={700}
                    animationDuration={1800}
                  />
                </BarChart>
              </ResponsiveContainer>
            </CardContent>
          </Card>
        </div>

        {/* Enhanced market impact with perfect symmetry */}
        <div className="mb-16 lg:mb-20">
          <div className="text-center mb-8 lg:mb-12 fade-in-up">
            <div className="flex items-center justify-center mb-6">
              <div className="w-20 h-px bg-gradient-to-r from-transparent via-primary to-transparent"></div>
              <div className="px-8">
                <div className="p-4 dark-glass rounded-full border border-primary/30">
                  <Zap className="h-8 w-8 text-primary" />
                </div>
              </div>
              <div className="w-20 h-px bg-gradient-to-r from-primary via-primary to-transparent"></div>
            </div>
            <h3 className="text-2xl md:text-3xl lg:text-4xl text-foreground">
              Доказано <span className="text-primary">въздействие</span>
            </h3>
          </div>
          
          <div className="grid md:grid-cols-3 gap-8 lg:gap-12">
            {marketStats.map((stat, index) => {
              const icons = [Users, Eye, BarChart3];
              const Icon = icons[index];
              const gradients = [
                "from-pink-500/20 to-pink-600/5",
                "from-cyan-500/20 to-cyan-600/5",
                "from-violet-500/20 to-violet-600/5"
              ];
              return (
                <div key={index} className={`dark-glass rounded-xl p-8 border border-border hover:border-primary/50 card-hover group text-center bg-gradient-to-br ${gradients[index]} fade-in-up`} style={{animationDelay: `${index * 0.2}s`}}>
                  <div className="w-16 h-16 mx-auto mb-6 rounded-full bg-primary/15 flex items-center justify-center group-hover:bg-primary/25 transition-all duration-300 group-hover:scale-110">
                    <Icon className="h-8 w-8 text-primary" />
                  </div>
                  <div className="text-4xl lg:text-5xl text-primary mb-4 font-bold group-hover:scale-105 transition-transform">
                    {stat.value}
                  </div>
                  <div className="text-foreground font-semibold mb-3 text-lg">{stat.label}</div>
                  <div className="text-sm lg:text-base text-muted-foreground">{stat.subtitle}</div>
                </div>
              );
            })}
          </div>
        </div>
      </div>
    </section>
  );
}