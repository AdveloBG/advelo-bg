import { useTheme } from "./ThemeProvider";
import adveloLogoDark from "figma:asset/473255efd3132647e7de3da99b12aad71a28cb72.png";
import adveloLogoLight from "figma:asset/e377968ce0781b86336a0c308f03923e761eabb3.png";

interface ThemeAwareLogoProps {
  className?: string;
  alt?: string;
}

export function ThemeAwareLogo({ className, alt = "Advelo Logo" }: ThemeAwareLogoProps) {
  const { theme } = useTheme();
  
  // Dark theme: use light logo (white letters)
  // Light theme: use dark logo (dark letters) 
  const logoSrc = theme === 'dark' ? adveloLogoLight : adveloLogoDark;
  
  return (
    <img 
      src={logoSrc} 
      alt={alt}
      className={className}
    />
  );
}