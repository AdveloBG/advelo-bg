export const impressionData = [
  { time: "6ч", impressions: 18500 },
  { time: "9ч", impressions: 45200 },
  { time: "12ч", impressions: 52800 },
  { time: "15ч", impressions: 48600 },
  { time: "18ч", impressions: 56900 },
  { time: "21ч", impressions: 32400 },
];

export const performanceData = [
  { month: "Ян", traditional: 15, mobileLED: 62 },
  { month: "Фев", traditional: 18, mobileLED: 68 },
  { month: "Мар", traditional: 16, mobileLED: 71 },
  { month: "Апр", traditional: 20, mobileLED: 74 },
  { month: "Май", traditional: 17, mobileLED: 78 },
  { month: "Юни", traditional: 19, mobileLED: 82 },
];

export const audienceData = [
  { name: "18-25", value: 28, color: "#39ff14" },
  { name: "26-35", value: 35, color: "#2ed10c" },
  { name: "36-45", value: 22, color: "#7fff4d" },
  { name: "46-55", value: 12, color: "#ffffff" },
  { name: "55+", value: 3, color: "#888888" },
];

export const locationData = [
  { location: "Център София", reach: 120000 },
  { location: "Търговски центрове", reach: 95000 },
  { location: "Бизнес зони", reach: 78000 },
  { location: "Летище София", reach: 85000 },
  { location: "Жилищни квартали", reach: 65000 },
  { location: "Развлекателни зони", reach: 102000 },
];

export const keyMetrics = [
  { value: "500К+", label: "Месечни импресии на екран" },
  { value: "47%", label: "По-евтино от билборд (CPM)" },
  { value: "92%", label: "Повече внимание от публиката" },
  { value: "120+", label: "Локации дневно с 1 екран" },
];

export const marketStats = [
  {
    value: "3x",
    label: "По-висок Brand Recall",
    subtitle: "Спрямо статична реклама"
  },
  {
    value: "2.3x",
    label: "По-пълно визуално задържане",
    subtitle: "В сравнение със статичен билборд"
  },
  {
    value: "15x",
    label: "Повече експозиция в движение",
    subtitle: "Спрямо статични локации"
  }
];

export const dailyStats = [
  {
    metric: "Средно локации на ден",
    value: "120+",
    description: "с само 1 LED екран"
  },
  {
    metric: "Месечни импресии",
    value: "6.2M",
    description: "в централни маршрути"
  },
  {
    metric: "Часове активност",
    value: "8-10ч",
    description: "дневно в ключови зони"
  },
  {
    metric: "Търсят бизнес",
    value: "73%",
    description: "от хората видели иновативен дисплей"
  }
];

export const comparisonStats = [
  {
    category: "Стойност на CPM",
    traditional: 25,
    advelo: 13.25,
    improvement: "47% по-евтино"
  },
  {
    category: "Дневни експозиции", 
    traditional: 1,
    advelo: 5,
    improvement: "5x повече гледания"
  },
  {
    category: "Визуално задържане",
    traditional: 1,
    advelo: 2.3,
    improvement: "2.3x по-дълго"
  },
  {
    category: "Brand Recall",
    traditional: 1,
    advelo: 3,
    improvement: "3x по-запомнящо"
  }
];