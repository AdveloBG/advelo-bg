// API utilities for contact form and other backend interactions

interface ContactFormData {
  name: string;
  email: string;
  phone: string;
  company: string;
  screens: string;
  period: string;
  message: string;
}

interface ApiResponse<T> {
  success: boolean;
  data?: T;
  error?: string;
}

// Simulate API delay for demo purposes
const delay = (ms: number) => new Promise(resolve => setTimeout(resolve, ms));

export async function submitContactForm(formData: ContactFormData): Promise<ApiResponse<string>> {
  try {
    await delay(1500); // Simulate network delay

    // In a real implementation, you would send this to your backend
    console.log('Contact form submitted:', formData);

    // For demo purposes, simulate success
    // Replace this with actual API call:
    /*
    const response = await fetch('/api/contact', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify(formData),
    });

    if (!response.ok) {
      throw new Error('Failed to submit form');
    }

    const result = await response.json();
    return { success: true, data: result.message };
    */

    return { 
      success: true, 
      data: 'Благодарим ви за запитването! Ще се свържем с вас в рамките на 24 часа.' 
    };

  } catch (error) {
    console.error('Contact form error:', error);
    return { 
      success: false, 
      error: 'Възникна грешка при изпращането. Моля, опитайте отново.' 
    };
  }
}

// Email validation utility
export function isValidEmail(email: string): boolean {
  const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
  return emailRegex.test(email);
}

// Phone number validation for Bulgarian numbers
export function isValidBulgarianPhone(phone: string): boolean {
  // Remove all non-digit characters
  const cleanPhone = phone.replace(/\D/g, '');
  
  // Check for Bulgarian phone number patterns
  // Mobile: 087/088/089/098/099 + 7 digits
  // Landline: 02/032/052/etc + 6-7 digits
  const mobileRegex = /^359(87|88|89|98|99)\d{7}$|^0(87|88|89|98|99)\d{7}$/;
  const landlineRegex = /^359\d{8,9}$|^0\d{8,9}$/;
  
  return mobileRegex.test(cleanPhone) || landlineRegex.test(cleanPhone);
}

// Format phone number for display
export function formatPhoneNumber(phone: string): string {
  const cleanPhone = phone.replace(/\D/g, '');
  
  if (cleanPhone.startsWith('359')) {
    // International format
    if (cleanPhone.length === 12) {
      return `+${cleanPhone.slice(0, 3)} ${cleanPhone.slice(3, 5)} ${cleanPhone.slice(5, 8)} ${cleanPhone.slice(8)}`;
    }
  } else if (cleanPhone.startsWith('0')) {
    // National format
    if (cleanPhone.length === 10) {
      return `${cleanPhone.slice(0, 3)} ${cleanPhone.slice(3, 6)} ${cleanPhone.slice(6)}`;
    }
  }
  
  return phone; // Return original if can't format
}

// Analytics tracking (replace with your analytics service)
export function trackEvent(eventName: string, properties?: Record<string, any>) {
  // Example with Google Analytics 4
  if (typeof window !== 'undefined' && 'gtag' in window) {
    (window as any).gtag('event', eventName, properties);
  }
  
  // Example with custom analytics
  console.log(`Analytics: ${eventName}`, properties);
}

// Performance monitoring
export function trackPerformance() {
  if (typeof window === 'undefined') return;
  
  // Track Core Web Vitals
  import('web-vitals').then(({ onFID, onTTFB, onLCP, onCLS, onFCP }) => {
    onFID((metric) => {
      trackEvent('web_vital', {
        name: metric.name,
        value: metric.value,
        rating: metric.rating
      });
    });
    
    onTTFB((metric) => {
      trackEvent('web_vital', {
        name: metric.name,
        value: metric.value,
        rating: metric.rating
      });
    });
    
    onLCP((metric) => {
      trackEvent('web_vital', {
        name: metric.name,
        value: metric.value,
        rating: metric.rating
      });
    });
    
    onCLS((metric) => {
      trackEvent('web_vital', {
        name: metric.name,
        value: metric.value,
        rating: metric.rating
      });
    });
    
    onFCP((metric) => {
      trackEvent('web_vital', {
        name: metric.name,
        value: metric.value,
        rating: metric.rating
      });
    });
  });
}